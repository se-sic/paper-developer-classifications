## Copyright 2020 Nils Alznauer <s9nialzn@stud.uni-saarland.de>
## Copyright 2021 Thomas Bock <bockthom@cs.uni-saarland.de>
## All Rights Reserved.

## Setup the different networks that are needed. Namely cochange and issue. Further network changes shall take place here, so that every type of network only needs
## to be established once as to reduce overhead.

## CONFIGURE AND RETRIEVE NETWORK(S)

network_creation <- function(project.data, relation, directed, simplify, author.only.committers){
  network.configuration <- NetworkConf$new()
  network.builder <- NetworkBuilder$new(project.data, network.configuration)
  network <- network.configuration$update.values((updated.values = list(author.relation = relation,
                                                                        artifact.relation = ARTIFACT.RELATION,
                                                                        author.directed = directed,
                                                                        #artifact.directed = directed, # currently ignored
                                                                        simplify = simplify,
                                                                        author.only.committers = author.only.committers)))
  return(network.builder$get.author.network())
}
