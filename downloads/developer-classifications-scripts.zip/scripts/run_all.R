## Copyright 2020 Nils Alznauer <s9nialzn@stud.uni-saarland.de>
## Copyright 2021-2022 Thomas Bock <bockthom@cs.uni-saarland.de>
## All Rights Reserved.

## This script shall be called to create a table that will denote the similarity between the different measures and the ground truth

## SOURCE NECESSARY SCRIPTS
source("./coronet/util-init.R", chdir = TRUE) # mandatory
source("./configuration.R") # mandatory

## LOAD NEEDED LIBRARIES
library("igraph")
library("dplyr")
library("tibble")
library("ggplot2")
library("ggpubr")
library("xtable")
library("grid")
library("gridExtra")
library("stringr")

## LOAD FURTHER SCRIPTS

source(sprintf("./scripts/settings/%s.R", CASESTUDY))
source("./scripts/settings/settings.R")
source("./scripts/classification_calls.R")
source("./scripts/setup.R")
source("./scripts/analysis.R") # run the analysis of the tables concerning the core developers
source("./scripts/plotting.R")
source("./scripts/plotting_data_for_paper.R")

## CONFIGURE PARAMETERS ONLY NEEDED FOR THIS SCRIPT

LOG.LEVEL = "INFO"
LOG.RESET = LOG.LEVEL

# initialize logging package (stdout + log file)
logging::logReset()
logging::basicConfig(level = LOG.LEVEL)

ANALYSIS = "threemonth"
SOURCE = "github"
DISCRETISATION.NAME = gsub("PerTimeWindow", "", DISCRETISATION.NAME)

if (NETWORKS.AUTHORS == "onlyCurrentContributors") {
  loginfo("Building networks with only current contributors")
  NETWORKS.AUTHOR.INCLUDING.PREVIOUS.COMMITTERS = FALSE
  NETWORKS.AUTHOR.ONLY.COMMITTERS = TRUE
} else if (NETWORKS.AUTHORS == "onlyPreviousContributors") {
  loginfo("Building networks with only previous contributors")
  NETWORKS.AUTHOR.INCLUDING.PREVIOUS.COMMITTERS = TRUE
  NETWORKS.AUTHOR.ONLY.COMMITTERS = FALSE
} else {
  loginfo("Building networks with all contributors")
  NETWORKS.AUTHOR.INCLUDING.PREVIOUS.COMMITTERS = FALSE
  NETWORKS.AUTHOR.ONLY.COMMITTERS = FALSE
}

## CONFIGURE AND RETRIEVE NETWORK(S)
## setup.R creates all the needed networks once based on the AUTHOR.RELATION selected

network_analyzation <-
  function(directed, simplify, casestudy, case) {
    project.configuration <-
      ProjectConf$new(DATA.PATH, ANALYSIS.RANGE.TYPE, CASESTUDY, ARTIFACT)
    project.configuration$update.value("issues.from.source", SOURCE)
    project.configuration$update.value("issues.only.comments", FALSE)
    project.configuration$update.value("filter.bots", TRUE)
    project.data <- ProjectData$new(project.configuration)

    # Should not be necesary any more in coronet 4.0
    project.data$set.issues(
      filter(
        project.data$get.issues(),
        # event.name != "referenced_by", 
        # creation.date <= date # not necessary any more (already done by coronet)
        #&
        author.name != "Deleted user"
        & author.name != "Deleted User"
        & author.name != "deleted user"
      )
    )

    #project.data <- filter_issues(project.data) # not necessary any more (already done by coronet)

    project.data <-
      project.data$get.data.cut.to.same.date(data.sources = c("mails", "commits", "issues")) 

    determine.time.differences.between.events.that.require.write.permission(project.data$get.issues(), file.path(OUTPUT.PATH, CASESTUDY),
                                                                            include.extended.events = FALSE)
    determine.time.differences.between.events.that.require.write.permission(project.data$get.issues(), file.path(OUTPUT.PATH, CASESTUDY),
                                                                            include.extended.events = TRUE)


    data.ranges <-
      split.data.time.based(project.data = project.data, time.period = TIME.PERIOD, sliding.window = SLIDING.WINDOW)

    # remove last range as it may be incomplete
    bins <- attr(data.ranges, "bins")
    data.ranges <- data.ranges[-length(data.ranges)]
    attr(data.ranges, "bins") = bins[-length(bins)]

    element_path <- file.path( OUTPUT.PATH, CASESTUDY, DISCRETISATION.NAME)
    pathing <- sprintf("%s/network_output", element_path)
    dir.create(pathing, showWarnings = FALSE, recursive = TRUE)

    all_authors_table <- list()

    if (NETWORKS.AUTHORS == "onlyPreviousContributors" || NETWORKS.AUTHORS == "onlyCurrentContributors") {
      all_contributor_authors_table <- list()
    }

    networks = list()
    classification.results <- data.frame()

    for (i in 1:length(data.ranges)) {
      ranged.data <- data.ranges[[i]]

      name <- substr(ranged.data$get.range(), 0, 10)

      all_authors_table[name] <-
        list(sort(unique(
          ranged.data$get.issues()$author.name
        )))

      if (NETWORKS.AUTHORS == "onlyPreviousContributors" || NETWORKS.AUTHORS == "onlyCurrentContributors") {

        if (NETWORKS.AUTHORS == "onlyPreviousContributors") {
          contributing.authors.with.data = project.data$get.commits.unfiltered()[, c("author.name", "date")]
          end.of.range = get.range.bounds(ranged.data$get.range())[2]
          previous.contributing.authors = contributing.authors.with.data[contributing.authors.with.data[["date"]] < end.of.range, ]
          contributing.authors = unique(previous.contributing.authors[["author.name"]])
        } else { # if (NETWORKS.AUTHORS == "onlyCurrentContributors") {
          contributing.authors.with.data = ranged.data$get.commits.unfiltered()[, c("author.name", "date")]
          contributing.authors = unique(contributing.authors.with.data[["author.name"]])
        }

        current.authors = unique(ranged.data$get.issues()$author.name)
        current.contributing.authors = current.authors[current.authors %in% contributing.authors]

        all_contributor_authors_table[name] <-
          list(sort(unique(
            current.contributing.authors
          )))
      }

      create_gt_table(
        project.data = project.data,
        ranged.data = ranged.data,
        file.name = name,
        path = element_path,
        case = case
      )

      main_table <- list()
      range.networks <- list()

      ## RUN NECESSARY SCRIPTS

      for (relation in AUTHOR.RELATION) {
        # run the different network classifications on all the networks at hand
        network <-
          network_creation(
            project.data = ranged.data,
            relation = relation,
            directed = directed,
            simplify = simplify,
            author.only.committers = NETWORKS.AUTHOR.ONLY.COMMITTERS
          )
          if (NETWORKS.AUTHOR.INCLUDING.PREVIOUS.COMMITTERS) {
            loginfo("Delete vertices of authors who have not previously contributed yet...")
            contributing.authors.with.data = project.data$get.commits.unfiltered()[, c("author.name", "date")]
            end.of.range = get.range.bounds(ranged.data$get.range())[2]
            previous.contributing.authors = contributing.authors.with.data[contributing.authors.with.data[["date"]] < end.of.range, ]
            contributing.authors = unique(previous.contributing.authors[["author.name"]])
            authors.in.network = igraph::get.vertex.attribute(network, "name")
            loginfo(setdiff(authors.in.network, contributing.authors))
            network = igraph::delete.vertices(network, setdiff(authors.in.network, contributing.authors))
          }
        range.networks[[paste(relation, collapse = "-")]] = network

        for (classification in CLASSIFICATION) {
          classification.result <- switch(
            classification,
            "network_degree" = {
              network_degree(main_table,
                             network,
                             relation,
                             project.configuration,
                             name,
                             case)
            },
            "network_eigen" = {
              network_eigen(main_table,
                            network,
                            relation,
                            project.configuration,
                            name,
                            case)
            },
            "network_hierarchy" = {
              network_hierarchy(main_table,
                                network,
                                relation,
                                project.configuration,
                                name,
                                case)
            },
            "commit_count" = {
              commit_count(main_table,
                           network,
                           relation,
                           project.configuration,
                           ranged.data,
                           name,
                           case)
            },
            "loc_count" = {
              loc_count(main_table,
                        network,
                        relation,
                        project.configuration,
                        ranged.data,
                        name,
                        case)
            }

          )

          if(nrow(classification.results) == 0 || nrow(classification.result[[1]]) == 0) {
            classification.results = rbind(classification.results, classification.result[[1]])
          } else {
            classification.results = as.data.frame(full_join(classification.results, classification.result[[1]])
                                                   %>% group_by(author.name, project, range, simplified.directed)
                                                   %>% summarise(across(everything(), ~ first(.[order(is.na(.))])), .groups = 'drop'))
          }

          main_table = classification.result[[2]]
        }
      }

      networks[[name]] = range.networks

      saveRDS(main_table, file = sprintf("%s/%s_%s_%s.rds", pathing, case, DISCRETISATION.NAME, name))
    } # this bracket is needed always

    write.csv(classification.results, file = sprintf("%s/%s_%s_metrics.csv", pathing, case, DISCRETISATION.NAME), row.names = FALSE) # NETWORKS.AUTHORS is already part of the DISCRETISATION.NAME)

    saveRDS(networks,
            file = sprintf("%s/%s_%s_networks.rds", pathing, case, DISCRETISATION.NAME)) # NETWORKS.AUTHORS is already part of the DISCRETISATION.NAME
   #save(networks, file = sprintf("%s/%s_%s_networks.rdata", pathing, case, DISCRETISATION.NAME)) # NETWORKS.AUTHORS is already part of the DISCRETISATION.NAME
    saveRDS(all_authors_table,
            file = sprintf("%s/%s_%s_all.rds", pathing, case, DISCRETISATION.NAME)) # NETWORKS.AUTHORS is already part of the DISCRETISATION.NAME

  }

run <- function() {
   for (case in SIMPLIFY.DIRECTED) {
     switch(
       case,
       "FF" = {
         simplify <- FALSE
         directed <- FALSE
       },
       "FT" = {
         simplify <- FALSE
         directed <- TRUE
       },
       "TF" = {
         simplify <- TRUE
         directed <- FALSE
       },
       "TT" = {
         simplify <- TRUE
         directed <- TRUE
       }
     )
     network_analyzation(
       directed = directed,
       simplify = simplify,
       casestudy = CASESTUDY,
       case = case
     )
   }

  element_path <- file.path(OUTPUT.PATH, CASESTUDY, DISCRETISATION.NAME)
  create_truth_table(path = element_path)
  plotting(create_df(), devices = c("png", "pdf", "tikz"))

  extract.data.for.plotting(create_df())
  extract.data.for.plotting(create_df(gt_devs_not_part_of_classification = TRUE), gt_devs_not_part_of_classification = TRUE)
  extract.data.for.plotting(create_df(gt_devs_not_part_of_classification = TRUE, relative = TRUE), gt_devs_not_part_of_classification = TRUE, relative = TRUE)
  extract.sizes.data.for.plotting(create_sizes_dfs())
  extract.jaccard.overlap.data.for.plotting(create_df(), create_sizes_dfs()[[1]])
}

run()
source("scripts/overall-plotting.R")
