## Copyright 2021-2023 Thomas Bock <bockthom@cs.uni-saarland.de>
## All Rights Reserved.

source("./scripts/settings/settings.R")

library("RColorBrewer")
options(tikzMetricPackages = c("\\usepackage[utf8]{inputenc}","\\usepackage[T1]{fontenc}", "\\usetikzlibrary{calc}", "\\usepackage{amssymb}"))

CC.LABEL           = "commit count"
LOC.LABEL          = "LOC count"
CNET.DEGREE.LABEL  = "degree cochange"
CNET.HIER.LABEL    = "hierarchy cochange"
CNET.EIGEN.LABEL   = "eigen-cent. cochange"
INET.DEGREE.LABEL  = "degree issue"
INET.HIER.LABEL    = "hierarchy issue"
INET.EIGEN.LABEL   = "eigen-cent. issue"
CINET.DEGREE.LABEL = "degree cochange+issue"
CINET.HIER.LABEL   = "hierarchy cochange+issue"
CINET.EIGEN.LABEL  = "eigen-cent. cochange+issue"

adjust.string = function(string) {
    adjusted.string = switch(string,
        # Network Vertices
        "all" = "all contributors",
        "onlyPreviousContributors" = "code contributors",

        # Projects
        "angular" = "Angular",
        "atom" = "Atom",
        "bootstrap" = "Bootstrap",
        "deno" = "Deno",
        "electron" = "Electron",
        "flutter" = "Flutter",
        "google-data-transfer-project" = "DTP",
        "jquery" = "jQuery",
        "keras" = "Keras",
        "kubernetes" = "Kubernetes",
        "moby" = "Moby",
        "nextcloud" = "Nextcloud",
        "nextjs" = "Next.js",
        "nodejs" = "Node.js",
        "openssl-github" = "OpenSSL",
        "owncloud-github" = "ownCloud",
        "react" = "React",
        "redux" = "Redux",
        "revealjs" = "reveal.js",
        "tensorflow" = "TensorFlow",
        "threejs" = "three.js",
        "typescript" = "TypeScript",
        "vscode" = "VS Code",
        "vue" = "Vue",
        "webpack" = "webpack",

        # Simplified directed
        "TT" = "simplified directed",
        "TF" = "simplified undirected",
        "FT" = "unsimplified directed",
        "FF" = "unsimplified undirected",

        # sliding window
        "sliding_window" = "sliding",

        # time period
        "6months" = "6 months",
        "3months" = "3 months",
        "9months" = "9 months",
        "12months" = "12 months",

        # sizes
        "ground truth" = "ground truth",
        "classified as core" = "classified as core",
        "classified as peripheral" = "classified as peripheral",

        string)

    return(adjusted.string)
}

combine.classification.results <- function(list.of.casestudies, sd) {
    all.classification.results = data.frame()

    for(casestudy in list.of.casestudies) {
        logging::loginfo("Get metrics for project %s", casestudy)
        path = file.path(OUTPUT.PATH, casestudy, DISCRETISATION.NAME, "network_output", paste(sd, DISCRETISATION.NAME, "metrics.csv", sep = "_"))
        
        if (!file.exists(path)) {
            logging::loginfo(sprintf("No data for project %s available", casestudy))
        } else {

            classification.results = read.csv(path, header = TRUE, check.names = FALSE)

            classification.results <- filter(classification.results, simplified.directed == sd)
            classification.results <- classification.results[, !(grepl("(issue-mail)|(cochange-mail)|(mail)|(commitcount_issue)|(loccount_issue)|(commitcount_cochange-issue)|(loccount_cochange-issue)",
                                                                   colnames(classification.results)))]
            colnames(classification.results)[colnames(classification.results) == "loccount_cochange"] = "loccount"
            colnames(classification.results)[colnames(classification.results) == "classification_loccount_cochange"] = "classification_loccount"
            colnames(classification.results)[colnames(classification.results) == "commitcount_cochange"] = "commitcount"
            colnames(classification.results)[colnames(classification.results) == "classification_commitcount_cochange"] = "classification_commitcount"

            # remove developers who only occur in mail data but not in commit data nor in issue data
            classification.results <- classification.results[!is.na(classification.results[["classification_loccount"]])
                                                             | !is.na(classification.results[["classification_commitcount"]])
                                                             | !is.na(classification.results[["classification_degree_cochange"]])
                                                             | !is.na(classification.results[["classification_eigen_cochange"]])
                                                             | !is.na(classification.results[["classification_hierarchy_cochange"]])
                                                             | !is.na(classification.results[["classification_degree_issue"]])
                                                             | !is.na(classification.results[["classification_eigen_issue"]])
                                                             | !is.na(classification.results[["classification_hierarchy_issue"]])
                                                             | !is.na(classification.results[["classification_degree_cochange-issue"]])
                                                             | !is.na(classification.results[["classification_eigen_cochange-issue"]])
                                                             | !is.na(classification.results[["classification_hierarchy_cochange-issue"]]), ]

            # add GT information
            path_to_read_in_GT <- file.path(OUTPUT.PATH, casestudy, DISCRETISATION.NAME, "GT")
            all_GT_files <- list.files(path = path_to_read_in_GT, pattern = "*\\.rds")

            for (i in seq_along(all_GT_files)) {
                file = all_GT_files[[i]]

                #name = substr(file, 1, 10) # substr(file, 4, 13)
                start_date = substr(file, nchar(file)-13, nchar(file)-13 + 9)

                gt_table <- readRDS(file = sprintf("%s/%s", path_to_read_in_GT, file)) #DISCRETISATION.NAME, name))

                for (gt in c("issues", "issuesInclExtended")) {

                    # temporal smoothness assumption: if a developer was present in the previous GT file and is present in the subsequent GT file,
                    # then we assume they should also belong to the current GT file (maybe not present for illness or holiday reasons)
                    if (i > 1 && i < length(all_GT_files)) { #(gt == "issues" || gt == "issuesInclExtended") &&
                        previous_file = all_GT_files[[i-1]]
                        previous_gt_table = readRDS(file = sprintf("%s/%s", path_to_read_in_GT, previous_file)) #DISCRETISATION.NAME, name))

                        subsequent_file = all_GT_files[[i+1]]
                        subsequent_gt_table = readRDS(file = sprintf("%s/%s", path_to_read_in_GT, subsequent_file)) #DISCRETISATION.NAME, name))

                        # check who is in the previous AND subsequent GT
                        gt_people_available_before_and_after = intersect(previous_gt_table[[gt]], subsequent_gt_table[[gt]])

                        # determine which people are in previous AND subsequent GT but not in current GT
                        gt_people_missing_now = setdiff(gt_people_available_before_and_after, gt_table[[gt]])
                        logging::loginfo(sprintf("Add the following devs to the GT who have been present in GT previously and subsequently but not currently: %s (%s)",
                                             length(gt_people_missing_now), paste(gt_people_missing_now, collapse = ", ")))

                        # add people present in both previous AND subsequent GT to the current GT
                        gt_table[[gt]] = union(gt_table[[gt]], gt_people_available_before_and_after)
                    }

                    if (length(gt_table[[gt]]) > 0) {
                        core = data.frame("author.name" = gt_table[[gt]], "eventClassification" = "core")
                        core[["range"]] = start_date
                        core[["project"]] = casestudy
                        core[["simplified.directed"]] = sd
                        colnames(core)[colnames(core) == "eventClassification"] = paste("eventClassification", gt, sep = "_")

                        classification.results = as.data.frame(full_join(classification.results, core)
                                                               %>% group_by(project, range, simplified.directed, author.name)
                                                               %>% summarise(across(everything(), ~ first(.[order(is.na(.))])), .groups = 'drop'))
                    }
                }
            }

            classification.results = classification.results %>% select(project, range, simplified.directed, author.name, eventClassification_issues,
                                                                       eventClassification_issuesInclExtended, commitcount, classification_commitcount,
                                                                       loccount, classification_loccount, everything())

            all.classification.results = rbind(all.classification.results, classification.results)
        }
    }

    # sort by project, sd, range, author
    all.classification.results = all.classification.results[order(all.classification.results[["project"]], all.classification.results[["range"]],
                                                                  all.classification.results[["simplified.directed"]], all.classification.results[["author.name"]]), ]

    output.path = file.path(OUTPUT.PATH, "overall-plots", DISCRETISATION.NAME, "classification_results")
    dir.create(output.path, showWarnings = FALSE, recursive = TRUE)
    write.csv(all.classification.results, file = file.path(output.path, paste(sd, DISCRETISATION.NAME, "metrics_all-projects.csv", sep = "_")),
              row.names = FALSE, col.names = TRUE)
}

extract.data.for.plotting <- function(df, gt_devs_not_part_of_classification = FALSE, relative = FALSE, sd) {
    for (ground.truth in GROUND_TRUTHS) {
        for (compute_gt_set in COMPUTE_GT_SET) {

            if (gt_devs_not_part_of_classification) {
                if (compute_gt_set == "CoreClassification") {
                    # choose only the correct metric for this plot
                    df[["metric"]] = NULL
                    df[["similarity metric"]] = NULL
                    df = unique(df)
                    df1 <- filter(df, compute_set == compute_gt_set & Ground_Truth == ground.truth)
                    df2 <- filter(df, compute_set == compute_gt_set & Ground_Truth == ground.truth)

                    gt = paste("GT", ground.truth, sep="-")
                    comparison_set = paste("ComparisonSet", compute_gt_set, sep="-")
                    data.for.plotting.path = file.path(OUTPUT.PATH, CASESTUDY, DISCRETISATION.NAME, "similarity", "evaluation-results", gt, comparison_set)
                    dir.create(data.for.plotting.path, showWarnings = FALSE, recursive = TRUE)

                    df_all <- filter(df2, simplify.directed == sd)
                    df_all_onlyUserCombinations <- df_all[, !(grepl("(is_ma)|(co_ma)|(mail)|(cc_issue)|(loc_issue)|(cc_co_is)|(loc_co_is)", colnames(df_all)))]

                    df_violin = tidyr::gather(df_all_onlyUserCombinations, key = "classification", value = "value", -start_date, -simplify.directed, -Ground_Truth, -compute_set)
                    #, -gt_devs_not_part_of_classification) #%>%
                    #   tidyr::gather(key = "classification", value = "devs_not_part_of_classification", "gt_devs_not_part_of_classification")
                    #save(df_violin, file = file.path(data.for.plotting.path, paste0("classification-results_", CASESTUDY, "_", TIME.PERIOD, ifelse(SLIDING.WINDOW, "_slidingWindow", ""), ".rdata")))
                    df_violin = df_violin[order(df_violin[["start_date"]]),]

                    df_violin$casestudy = CASESTUDY

                    relative_string = ""
                    if (relative) {
                        relative_string = "relative_"
                    }

                    casestudy.evaluation.results.file = file.path(data.for.plotting.path,
                                                              paste0("gt_", relative_string, "devs_not_part_of_classification-results_", sd, "_", CASESTUDY, "_", TIME.PERIOD, ifelse(SLIDING.WINDOW, "_slidingWindow_", "_"), NETWORKS.AUTHORS, "_",
                                                                     gt, "_", comparison_set, ".csv"))
                    logging::loginfo(sprintf("Extract gt_%sdevs_not_part_of_classification_results results to file: '%s'", relative_string, casestudy.evaluation.results.file))
                    write.csv(df_violin, file = casestudy.evaluation.results.file, col.names = TRUE, row.names = FALSE)
                }
            } else {

                #for (metric in METRICS) {
                metric = "Precision"
                    # choose only the correct metric for this plot
                    df1 <- filter(df, `similarity metric` == metric & compute_set == compute_gt_set & Ground_Truth == ground.truth)
                    df2 <- filter(df, compute_set == compute_gt_set & Ground_Truth == ground.truth)

                    gt = paste("GT", ground.truth, sep="-")
                    comparison_set = paste("ComparisonSet", compute_gt_set, sep="-")
                    data.for.plotting.path = file.path(OUTPUT.PATH, CASESTUDY, DISCRETISATION.NAME, "similarity", "evaluation-results", gt, comparison_set)
                    dir.create(data.for.plotting.path, showWarnings = FALSE, recursive = TRUE)

                    df_all <- filter(df2, simplify.directed == sd & `similarity metric` != "Jaccard" & `similarity metric` != "Overlap" & `similarity metric` != "Intersect" & `similarity metric` != "Union")
                    df_all_onlyUserCombinations <- df_all[, !(grepl("(is_ma)|(co_ma)|(mail)|(cc_issue)|(loc_issue)|(cc_co_is)|(loc_co_is)", colnames(df_all)))]

                    df_violin = tidyr::gather(df_all_onlyUserCombinations, key = "classification", value = "value", -start_date, -simplify.directed, -Ground_Truth, -`similarity metric`, -compute_set)
                    #, -gt_devs_not_part_of_classification) #%>%
                    #   tidyr::gather(key = "classification", value = "devs_not_part_of_classification", "gt_devs_not_part_of_classification")
                    #save(df_violin, file = file.path(data.for.plotting.path, paste0("classification-results_", CASESTUDY, "_", TIME.PERIOD, ifelse(SLIDING.WINDOW, "_slidingWindow", ""), ".rdata")))
                    df_violin = df_violin[order(df_violin[["start_date"]]),]

                    df_violin$casestudy = CASESTUDY

                    casestudy.evaluation.results.file = file.path(data.for.plotting.path,
                                                                  paste0("evaluation-results_", sd, "_", CASESTUDY, "_", TIME.PERIOD, ifelse(SLIDING.WINDOW, "_slidingWindow_", "_"), NETWORKS.AUTHORS, "_",
                                                                         gt, "_", comparison_set, ".csv"))
                    logging::loginfo(sprintf("Extract evaluation results to file: '%s'", casestudy.evaluation.results.file))
                    write.csv(df_violin, file = casestudy.evaluation.results.file, col.names = TRUE, row.names = FALSE)
                #}
            }
        }
    }

}

extract.sizes.data.for.plotting <- function(dfs, sd) {
    for (ground.truth in GROUND_TRUTHS) {
        for (compute_gt_set in COMPUTE_GT_SET) {

            if (compute_gt_set == "CoreClassification") {

                for(i in seq_along(dfs)) {
                    df = dfs[[i]]

                    # choose only the correct metric for this plot
                    df[["metric"]] = NULL
                    df[["similarity metric"]] = NULL
                    df = unique(df)
                    df1 <- filter(df, compute_set == compute_gt_set & Ground_Truth == ground.truth)
                    df2 <- filter(df, compute_set == compute_gt_set & Ground_Truth == ground.truth)

                    gt = paste("GT", ground.truth, sep="-")
                    comparison_set = paste("ComparisonSet", compute_gt_set, sep="-")
                    data.for.plotting.path = file.path(OUTPUT.PATH, CASESTUDY, DISCRETISATION.NAME, "similarity", "evaluation-results", gt, comparison_set)
                    dir.create(data.for.plotting.path, showWarnings = FALSE, recursive = TRUE)

                    df_all <- filter(df2, simplify.directed == sd)
                    df_all_onlyUserCombinations <- df_all[, !(grepl("(is_ma)|(co_ma)|(mail)|(cc_issue)|(loc_issue)|(cc_co_is)|(loc_co_is)", colnames(df_all)))]

                    df_violin = tidyr::gather(df_all_onlyUserCombinations, key = "classification", value = "value", -start_date, -simplify.directed, -Ground_Truth, -compute_set)
                    #, -gt_devs_not_part_of_classification) #%>%
                    #   tidyr::gather(key = "classification", value = "devs_not_part_of_classification", "gt_devs_not_part_of_classification")
                    #save(df_violin, file = file.path(data.for.plotting.path, paste0("sizes_", CASESTUDY, "_", TIME.PERIOD, ifelse(SLIDING.WINDOW, "_slidingWindow", ""), ".rdata")))
                    df_violin = df_violin[order(df_violin[["start_date"]]),]

                    df_violin$casestudy = CASESTUDY
                    name = names(dfs)[[i]]

                    casestudy.sizes.results.file = file.path(data.for.plotting.path,
                                                                  paste0(name, "_", sd, "_", CASESTUDY, "_", TIME.PERIOD, ifelse(SLIDING.WINDOW, "_slidingWindow_", "_"), NETWORKS.AUTHORS, "_",
                                                                         gt, "_", comparison_set, ".csv"))
                    logging::loginfo(sprintf("Extract %ss to file: '%s'", name, casestudy.sizes.results.file))
                    write.csv(df_violin, file = casestudy.sizes.results.file, col.names = TRUE, row.names = FALSE)
                }
            }
        }
    }

}

extract.jaccard.overlap.data.for.plotting <- function(truth.table.df, gt.sizes.df) {

    # Retrieve overlap/jaccard from truth.table.df:
    resulting.df = unique(truth.table.df[ truth.table.df[["compute_set"]] == "Other_GT"
                                          & (truth.table.df[["similarity metric"]] == "Overlap"
                                             | truth.table.df[["similarity metric"]] == "Jaccard"
                                             | truth.table.df[["similarity metric"]] == "Intersect"
                                             | truth.table.df[["similarity metric"]] == "Union")
                                          & truth.table.df[["Ground_Truth"]] != "committer",
                                          c("start_date", "Ground_Truth", "similarity metric", "compute_set", "nd_cochange")])
    names(resulting.df)[names(resulting.df) == "nd_cochange"] = "value"
    names(resulting.df)[names(resulting.df) == "compute_set"] = "ComparisonSet"

    # Retrieve GT sizes from gt.sizes.df
    gt.sizes.resulting.df = unique(gt.sizes.df[ (gt.sizes.df[["similarity metric"]] == "Overlap"
                                                 | gt.sizes.df[["similarity metric"]] == "Jaccard"
                                                 | gt.sizes.df[["similarity metric"]] == "Intersect"
                                                 | gt.sizes.df[["similarity metric"]] == "Union")
                                                & gt.sizes.df[["Ground_Truth"]] != "committer",
                                                c("start_date", "Ground_Truth", "similarity metric", "nd_cochange")])
    names(gt.sizes.resulting.df)[names(gt.sizes.resulting.df) == "nd_cochange"] = "GT_size"

    # Merge overlap/jaccard data and sizes data
    df = merge(resulting.df, gt.sizes.resulting.df, by = c("start_date", "Ground_Truth", "similarity metric"), all = TRUE)

    # Make similarity metric entries to an own column each
    df = df %>% tidyr::spread(key = `similarity metric`, value = value) %>%
            relocate("GT_size", .after = last_col()) %>%
            relocate("Intersect", .after = "Union")

    # Add size of committer list
    df[["committer_list_size"]] = length(review_committer()[[1]])

    # Compute overlap for both sides separately
    df[["percentage_gt_in_committer_list"]] = df[["Intersect"]] / df[["committer_list_size"]]
    df[["percentage_committer_list_in_gt"]] = df[["Intersect"]] / df[["GT_size"]]

    # Dump resulting csv file
    data.dumping.path = file.path(OUTPUT.PATH, CASESTUDY, DISCRETISATION.NAME, "similarity")
    dir.create(data.dumping.path, showWarnings = FALSE, recursive = TRUE)
    results.file = file.path(data.dumping.path,
                             paste0("JaccardOverlap_issuesGTs_OtherGT", CASESTUDY, "_", TIME.PERIOD, ifelse(SLIDING.WINDOW, "_slidingWindow_", "_"), NETWORKS.AUTHORS, ".csv"))
    logging::loginfo(sprintf("Extract jaccard and overlap data to file: '%s'", results.file))
    write.csv(df, file = results.file, col.names = TRUE, row.names = FALSE)
}

plot.all <- function(devices, list.of.casestudies, sd) {
    plot.path = file.path(OUTPUT.PATH, "overall-plots", DISCRETISATION.NAME)
    dir.create(plot.path, showWarnings = FALSE, recursive = TRUE)

    for (ground.truth in GROUND_TRUTHS) {
        for (compute_gt_set in COMPUTE_GT_SET) {

            gt = paste("GT", ground.truth, sep="-")
            comparison_set = paste("ComparisonSet", compute_gt_set, sep="-")

            data = data.frame()
            plot.path.individual = file.path(plot.path, gt, comparison_set)
            dir.create(plot.path.individual, showWarnings = FALSE, recursive = TRUE)

            available.casestudies = c()

            for (casestudy in list.of.casestudies) {
                data.path =  file.path(OUTPUT.PATH, casestudy, DISCRETISATION.NAME, "similarity", "evaluation-results", gt, comparison_set)

                casestudy.evaluation.results.file = file.path(data.path,
                                                              paste0("evaluation-results_", sd, "_", casestudy, "_", TIME.PERIOD, ifelse(SLIDING.WINDOW, "_slidingWindow_", "_"), NETWORKS.AUTHORS, "_",
                                                                     gt, "_", comparison_set, ".csv"))

                if (file.exists(casestudy.evaluation.results.file)) {
                    logging::loginfo(sprintf("Read file '%s'", casestudy.evaluation.results.file))
                    casestudy.data = read.csv(file = casestudy.evaluation.results.file, check.names = FALSE) # don't replace spaces in colnames by a point
                    data = rbind(data, casestudy.data)
                    available.casestudies = c(available.casestudies, casestudy)
                }
            }

            write.csv(data, file = file.path(plot.path.individual, paste(gt, comparison_set, sd, "overall-data.csv", sep = "_")))

            if (length(available.casestudies > 0)) {

                df_violin = data
                df_violin[df_violin[["classification"]] == "cc_cochange", "classification"] = CC.LABEL
                df_violin[df_violin[["classification"]] == "loc_cochange", "classification"] = LOC.LABEL
                df_violin[df_violin[["classification"]] == "nd_cochange", "classification"] = CNET.DEGREE.LABEL
                df_violin[df_violin[["classification"]] == "ne_cochange", "classification"] = CNET.EIGEN.LABEL
                df_violin[df_violin[["classification"]] == "nh_cochange", "classification"] = CNET.HIER.LABEL
                df_violin[df_violin[["classification"]] == "nd_issue", "classification"] = INET.DEGREE.LABEL
                df_violin[df_violin[["classification"]] == "ne_issue", "classification"] = INET.EIGEN.LABEL
                df_violin[df_violin[["classification"]] == "nh_issue", "classification"] = INET.HIER.LABEL
                df_violin[df_violin[["classification"]] == "nd_co_is", "classification"] = CINET.DEGREE.LABEL
                df_violin[df_violin[["classification"]] == "ne_co_is", "classification"] = CINET.EIGEN.LABEL
                df_violin[df_violin[["classification"]] == "nh_co_is", "classification"] = CINET.HIER.LABEL
                df_violin <- df_violin %>%
                    mutate( classification=factor(classification,levels=c(CC.LABEL, LOC.LABEL, CNET.DEGREE.LABEL, CNET.EIGEN.LABEL, CNET.HIER.LABEL,
                                                                          INET.DEGREE.LABEL, INET.EIGEN.LABEL, INET.HIER.LABEL ,
                                                                          CINET.DEGREE.LABEL, CINET.EIGEN.LABEL, CINET.HIER.LABEL)) )

                df_violin = df_violin[df_violin[["similarity metric"]] != "Specificity",]
                df_violin[["casestudy"]] = sapply(df_violin[["casestudy"]], adjust.string)

                # names(df_violin)[names(df_violin) == "start_date"] = "start date"
                # names(df_violin)[names(df_violin) == "simplify.directed"] = "simplified.directed"
                # names(df_violin)[names(df_violin) == "Ground_Truth"] = "Ground Truth"
                # names(df_violin)[names(df_violin) == "similarity metric"] = "similarity metric"
                # names(df_violin)[names(df_violin) == "compute_set"] = "comparison set"
                # names(df_violin)[names(df_violin) == "classification"] = "classificationt"
                # names(df_violin)[names(df_violin) == "value"] = "value"
                # names(df_violin)[names(df_violin) == "casestudy"] = "project"


                graph <- ggplot(data = df_violin, aes(x = start_date))

                graph <- graph + xlab('Classification Method') + ylab('') + #ylab('Similarity to Ground Truth') +
                    #    expand_limits(y = c(0, 1.0)) +
                    theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1, size = 7), axis.text.y = element_text(size = 7), plot.title = element_text(size = 10),
                          legend.text = element_text(size = 7), legend.title = element_blank(), #element_text(size = 7),
                          legend.key.size = unit(0.25, "cm"), legend.position = "top", axis.title.x = element_blank())

                 ## PART 1a: F1, Recall, Precision ##########################
                 # start with generating plots for each casestudy individually
                 for (casestudy in available.casestudies) {

                     df_violin_casestudy = df_violin[df_violin[["casestudy"]] == adjust.string(casestudy), ]

                     graph_byClassification <- graph +
                         geom_violin(data = df_violin_casestudy, aes(y = value, x = classification, color = `similarity metric`), position = position_dodge(width = 0.75), width = 1) +
                         geom_boxplot(data = df_violin_casestudy, aes(y = value, x = classification, color = `similarity metric`, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                         ggtitle(paste(adjust.string(casestudy), adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))

                     for (device in devices) {
                         device.name = device
                         if (device == 'tikz') device = tikzDevice::tikz
                         ggsave(sprintf("%s_byClassification_%s.%s", file.path(plot.path.individual, paste(casestudy, sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
                     }

                     graph_byEvaluationMetric <- graph +
                         geom_violin(data = df_violin_casestudy, aes(y = value, x = `similarity metric`, color = classification), position = position_dodge(width = 0.75), width = 1) +
                         geom_boxplot(data = df_violin_casestudy, aes(y = value, x = `similarity metric`, color = classification, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                         ggtitle(paste(adjust.string(casestudy), adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))

                     for (device in devices) {
                         device.name = device
                         if (device == 'tikz') device = tikzDevice::tikz
                         ggsave(sprintf("%s_byEvaluationMetric_%s.%s", file.path(plot.path.individual, paste(casestudy, sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
                     }

                     graph_byClassificationSeparateMetrics <- graph +
                         geom_violin(data = df_violin_casestudy, aes(y = value, x = classification, color = classification), position = position_dodge(width = 0.75), width = 1) +
                         geom_boxplot(data = df_violin_casestudy, aes(y = value, x = classification, color = classification, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                         facet_wrap(~ `similarity metric`) +
                         ggtitle(paste(adjust.string(casestudy), adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd),  adjust.string(NETWORKS.AUTHORS), sep = "   "))

                     for (device in devices) {
                         device.name = device
                         if (device == 'tikz') device = tikzDevice::tikz
                         ggsave(sprintf("%s_byClassificationSeparateMetrics_%s.%s", file.path(plot.path.individual, paste(casestudy, sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
                     }
                 }

                 ## PART 1b: F1, Recall, Precision ##########################
                 # start with generating plots for all casestudies together
                 graph_byClassification <- graph +
                     geom_violin(data = df_violin, aes(y = value, x = classification, color = `similarity metric`), position = position_dodge(width = 0.75), width = 1) +
                     geom_boxplot(data = df_violin, aes(y = value, x = classification, color = `similarity metric`, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                     facet_wrap(~ casestudy) +
                     ggtitle(paste(adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))

                 for (device in devices) {
                     device.name = device
                     if (device == 'tikz') device = tikzDevice::tikz
                     ggsave(sprintf("%s_byClassification_%s.%s", file.path(plot.path.individual, paste("allProjects", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name),  device = device)
                 }

                 graph_byEvaluationMetric <- graph +
                     geom_violin(data = df_violin, aes(y = value, x = `similarity metric`, color = classification), position = position_dodge(width = 0.75), width = 1) +
                     geom_boxplot(data = df_violin, aes(y = value, x = `similarity metric`, color = classification, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                     facet_wrap(~ casestudy) +
                     ggtitle(paste(adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))

                 for (device in devices) {
                     device.name = device
                     if (device == 'tikz') device = tikzDevice::tikz
                     ggsave(sprintf("%s_byEvaluationMetric_%s.%s", file.path(plot.path.individual, paste("allProjects", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name),  device = device)
                 }

                 graph_byClassificationSeparateMetrics <- graph +
                     geom_violin(data = df_violin, aes(y = value, x = classification, color = classification), position = position_dodge(width = 0.75), width = 1) +
                     geom_boxplot(data = df_violin, aes(y = value, x = classification, color = classification, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                     #facet_wrap(~ `similarity metric`) +
                     facet_wrap(casestudy ~ `similarity metric`) +
                     ggtitle(paste(adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))

                 for (device in devices) {
                     device.name = device
                     if (device == 'tikz') device = tikzDevice::tikz
                     ggsave(sprintf("%s_byClassificationSeparateMetrics_%s.%s", file.path(plot.path.individual, paste("allProjects", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name), device = device)
                 }

                 ## PART 1c: F1, Recall, Precision ##########################
                 # generate aggregated plots abstracting from casestudies
                 # start with generating plots for all casestudies together

                fontsize.original = 25

                for (device in devices) {
                    device.name = device
                    width = 16
                    height = 9
                    if (device == 'tikz') {
                        device = tikzDevice::tikz
                        fontsize = fontsize.original * 1.5
                        height = 1.1 * height
                    } else {
                        fontsize = fontsize.original
                    }

                graph_without_projects_byClassification <- graph +
                    geom_violin(data = df_violin, aes(y = value, x = classification, color = `similarity metric`), position = position_dodge(width = 0.75), width = 1) +
                    geom_boxplot(data = df_violin, aes(y = value, x = classification, color = `similarity metric`, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                    #facet_wrap(~ casestudy) +
                    theme(aspect.ratio = 9/27, text = element_text(size = fontsize), axis.text.x = element_text(size = fontsize),
                          axis.text.y = element_text(size = fontsize), legend.text = element_text(size = fontsize), legend.title = element_blank(), #element_text(size = fontsize),
                          plot.title = element_text(size = fontsize), legend.key.width = unit(1, "cm"), plot.margin = unit(c(0, 0, 0, 0), "cm")) +
                    ggtitle(paste(adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))


                    ggsave(sprintf("%s_byClassification_%s.%s", file.path(plot.path.individual, paste("allProjectsUnseparated", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name),  device = device,
                           height = height, width = width)
                }

                ## PART 2a: classification method ranking ##########################
                # Plot aggregated f1 measure per classification method for each project

                df_violin_f1 = unique(df_violin[ df_violin[["similarity metric"]] == "F1",])
                f1_per_project_and_method = aggregate(df_violin_f1[["value"]], list(df_violin_f1[["casestudy"]], df_violin_f1[["classification"]]), median)
                colnames(f1_per_project_and_method) = c("casestudy", "classification", "aggregated_value")
                f1_method_ranking_per_project = f1_per_project_and_method %>% group_by(casestudy) %>% mutate(ranking = rank(-aggregated_value, ties.method = "min"))

                for (device in devices) {
                    device.name = device
                    width = 16
                    height = 9
                    if (device == 'tikz') {
                        device = tikzDevice::tikz
                        fontsize = fontsize.original * 1.5
                        height = 1.1 * height
                    } else {
                        fontsize = fontsize.original
                    }

                    casestudy.colors = colorRampPalette(brewer.pal(8, "Set1"))(length(unique(df_violin_f1[["classification"]])))

                    graph_ranking_per_project <- graph + ylab('Median F1 across all Time Ranges') +
                        geom_col(data = f1_method_ranking_per_project, aes(y = aggregated_value, x = classification, fill = classification), position = position_dodge(width = 0.75), width = 1) +
                            scale_fill_manual(values = casestudy.colors) +
                            facet_wrap(~ casestudy) +
                        theme(aspect.ratio = 9/27, text = element_text(size = fontsize), axis.text.x = element_text(size = fontsize),
                              axis.text.y = element_text(size = fontsize), legend.text = element_text(size = fontsize), legend.title = element_blank(), # element_text(size = fontsize),
                              plot.title = element_text(size = fontsize), legend.key.width = unit(1, "cm"), plot.margin = unit(c(0, 0, 0, 0), "cm"),
                              legend.position = "none") +
                        ggtitle(paste(adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))


                    ggsave(sprintf("%s_rankings-per-project_%s.%s", file.path(plot.path.individual, paste("allProjects", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name),  device = device,
                           height = height, width = width)
                }

                ## PART 2b: classification method ranking ##########################
                # percentage of ranks1 across all projects

                rank1 = f1_method_ranking_per_project %>% group_by(classification) %>% summarize(rank1 = sum(ranking == 1))
                # rank2 = f1_method_ranking_per_project %>% group_by(classification) %>% summarize(rank1 = sum(ranking == 2))
                # rank3 = f1_method_ranking_per_project %>% group_by(classification) %>% summarize(rank1 = sum(ranking == 3))
                # rank4 = f1_method_ranking_per_project %>% group_by(classification) %>% summarize(rank1 = sum(ranking == 4))
                # rank5 = f1_method_ranking_per_project %>% group_by(classification) %>% summarize(rank1 = sum(ranking == 5))
                # rank6 = f1_method_ranking_per_project %>% group_by(classification) %>% summarize(rank1 = sum(ranking == 6))
                # rank7 = f1_method_ranking_per_project %>% group_by(classification) %>% summarize(rank1 = sum(ranking == 7))
                # rank8 = f1_method_ranking_per_project %>% group_by(classification) %>% summarize(rank1 = sum(ranking == 8))
                # rank9 = f1_method_ranking_per_project %>% group_by(classification) %>% summarize(rank1 = sum(ranking == 9))
                # rank10 = f1_method_ranking_per_project %>% group_by(classification) %>% summarize(rank1 = sum(ranking == 10))
                # rank11 = f1_method_ranking_per_project %>% group_by(classification) %>% summarize(rank1 = sum(ranking == 11))
                num_casestudies = length(available.casestudies)

                rank1[["percentage_of_projects"]] = rank1[["rank1"]] / num_casestudies
                # rank2[["percentage_of_projects"]] = rank1[["rank2"]] / num_casestudies
                # rank3[["percentage_of_projects"]] = rank1[["rank3"]] / num_casestudies
                # rank4[["percentage_of_projects"]] = rank1[["rank4"]] / num_casestudies
                # rank5[["percentage_of_projects"]] = rank1[["rank5"]] / num_casestudies
                # rank6[["percentage_of_projects"]] = rank1[["rank6"]] / num_casestudies
                # rank7[["percentage_of_projects"]] = rank1[["rank7"]] / num_casestudies
                # rank8[["percentage_of_projects"]] = rank1[["rank8"]] / num_casestudies
                # rank9[["percentage_of_projects"]] = rank1[["rank9"]] / num_casestudies
                # rank10[["percentage_of_projects"]] = rank1[["rank10"]] / num_casestudies
                # rank11[["percentage_of_projects"]] = rank1[["rank11"]] / num_casestudies

                for (device in devices) {
                    device.name = device
                    width = 16
                    height = 7
                    if (device == 'tikz') {
                        device = tikzDevice::tikz
                        fontsize = fontsize.original * 1.5
                        height = 1.1 * height
                    } else {
                        fontsize = fontsize.original
                    }

                    casestudy.colors = colorRampPalette(brewer.pal(8, "Set1"))(length(unique(df_violin_f1[["classification"]])))

                    graph_ranking_per_project <- graph +
                        ylab('Percentage of Projects \n at Rank 1') +
                        geom_col(data = rank1, aes(y = percentage_of_projects, x = classification, fill = classification), position = position_dodge(width = 0.75), width = 1) +
                        scale_fill_manual(values = casestudy.colors) +
                        theme(aspect.ratio = 9/35, text = element_text(size = fontsize), axis.text.x = element_text(size = fontsize),
                              axis.text.y = element_text(size = fontsize), legend.text = element_text(size = fontsize), legend.title = element_text(size = fontsize),
                              plot.title = element_text(size = fontsize), legend.key.width = unit(1, "cm"), plot.margin = unit(c(0, 0, 0, 0), "cm"),
                              legend.position = "none") +
                        ggtitle(paste(adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))


                    ggsave(sprintf("%s_rank1-percentage-of-projects_%s.%s", file.path(plot.path.individual, paste("allProjects", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name),  device = device,
                           height = height, width = width)
                }

                ## PART 2c: classification method ranking ##########################
                # histogram of ranks across all projects per classification method

                for (device in devices) {
                    device.name = device
                    width = 23
                    height = 9
                    if (device == 'tikz') {
                        device = tikzDevice::tikz
                        fontsize = fontsize.original * 1.5
                        height = 1.1 * height
                    } else {
                        fontsize = fontsize.original
                    }

                    casestudy.colors = colorRampPalette(brewer.pal(8, "Set1"))(length(unique(df_violin_f1[["classification"]])))

                    graph <- ggplot(data = df_violin, aes(x = start_date))

                    graph_ranking_per_project <- graph +
                        xlab('Rank') + ylab('Histogram of Rank in Different Projects') +
                        geom_histogram(data = f1_method_ranking_per_project, aes(x = ranking, fill = classification), position = position_dodge(width = 0.75)) +
                        scale_y_continuous(breaks = seq(0, 25, 2)) +
                        coord_cartesian(xlim = c(0,11), ylim = c(0,11)) +
                        coord_flip() + scale_x_reverse(breaks = seq(1, 11, 2)) +
                        scale_fill_manual(values = casestudy.colors) +
                        facet_wrap(~ classification, nrow = 1) +
                        theme(aspect.ratio = 12/9, text = element_text(size = fontsize), axis.text.x = element_text(size = fontsize),
                              axis.text.y = element_text(size = fontsize), legend.text = element_text(size = fontsize), legend.title = element_text(size = fontsize),
                              plot.title = element_text(size = fontsize), legend.key.width = unit(1, "cm"), plot.margin = unit(c(0, 0, 0, 0), "cm"),
                              legend.position = "none") +
                        ggtitle(paste(adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))


                    ggsave(sprintf("%s_rankings-accross-all-projects_%s.%s", file.path(plot.path.individual, paste("allProjects", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name),  device = device,
                           height = height, width = width)
                }

                ## PART 2d: classification method ranking ##########################
                # distributions of ranking of all projects per classification method

                for (device in devices) {
                    device.name = device
                    width = 16
                    height = 9
                    if (device == 'tikz') {
                        device = tikzDevice::tikz
                        fontsize = fontsize.original * 2.65
                        height = 1.97 * height
                        width = 1.8 * width
                    } else {
                        fontsize = fontsize.original
                    }

                    casestudy.colors = colorRampPalette(brewer.pal(8, "Set1"))(length(unique(df_violin_f1[["classification"]])))

                    graph <- ggplot(data = df_violin, aes(x = start_date))

                    graph_ranking_per_project <- graph +
                        ylab('Rank Distribution') +
                        geom_violin(data = f1_method_ranking_per_project, aes(y = ranking, x = classification, color = classification), position = position_dodge(width = 0.75), width = 1) +
                        geom_boxplot(data = f1_method_ranking_per_project, aes(y = ranking, x = classification, color = classification, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                        scale_y_reverse(breaks = seq(1, 11, 2)) +
                        theme(aspect.ratio = 9/25, text = element_text(size = fontsize), axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1, size = fontsize),
                              axis.title.x = element_blank(),
                              axis.text.y = element_text(size = fontsize), legend.text = element_text(size = fontsize), legend.title = element_blank(), #element_text(size = fontsize),
                              plot.title = element_text(size = fontsize), legend.key.width = unit(1, "cm"), plot.margin = unit(c(0, 0, 0, 0), "cm"),
                              legend.position = "none") +
                        ggtitle(paste(adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))


                    ggsave(sprintf("%s_distribution-rankings-accross-all-projects_%s.%s", file.path(plot.path.individual, paste("allProjects", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name),  device = device,
                           height = height, width = width)
                }

            }
        }
    }
}

plot.all.gt.devs.not.part.of.classification <- function(devices, list.of.casestudies, relative = FALSE, sd) {
    plot.path = file.path(OUTPUT.PATH, "overall-plots", DISCRETISATION.NAME)
    dir.create(plot.path, showWarnings = FALSE, recursive = TRUE)

    for (ground.truth in GROUND_TRUTHS) {
        for (compute_gt_set in COMPUTE_GT_SET) {

            if (compute_gt_set == "CoreClassification") {
                gt = paste("GT", ground.truth, sep="-")
                comparison_set = paste("ComparisonSet", compute_gt_set, sep="-")

                data = data.frame()
                relative_string = ""
                if (relative) {
                    relative_string = "relative_"
                }
                plot.path.individual = file.path(plot.path, gt, comparison_set, paste0("gt_", relative_string, "devs_not_part_of_classification"))
                dir.create(plot.path.individual, showWarnings = FALSE, recursive = TRUE)

                available.casestudies = c()

                for (casestudy in list.of.casestudies) {
                    data.path =  file.path(OUTPUT.PATH, casestudy, DISCRETISATION.NAME, "similarity", "evaluation-results", gt, comparison_set)

                    casestudy.evaluation.results.file = file.path(data.path,
                                                                  paste0("gt_", relative_string, "devs_not_part_of_classification-results_", sd, "_", casestudy, "_", TIME.PERIOD, ifelse(SLIDING.WINDOW, "_slidingWindow_", "_"), NETWORKS.AUTHORS, "_",
                                                                         gt, "_", comparison_set, ".csv"))

                    if (file.exists(casestudy.evaluation.results.file)) {
                        logging::loginfo(sprintf("Read file '%s'", casestudy.evaluation.results.file))
                        casestudy.data = read.csv(file = casestudy.evaluation.results.file, check.names = FALSE) # don't replace spaces in colnames by a point
                        data = rbind(data, casestudy.data)
                        available.casestudies = c(available.casestudies, casestudy)
                    }
                }
                write.csv(data, file = file.path(plot.path.individual, paste(gt, comparison_set, sd, paste0("gt_", relative_string, "devs_not_part_of_classification-data.csv"), sep = "_")))

                if (length(available.casestudies > 0)) {

                    df_violin = data
                    df_violin[df_violin[["classification"]] == "cc_cochange", "classification"] = CC.LABEL
                    df_violin[df_violin[["classification"]] == "loc_cochange", "classification"] = LOC.LABEL
                    df_violin[df_violin[["classification"]] == "nd_cochange", "classification"] = CNET.DEGREE.LABEL
                    df_violin[df_violin[["classification"]] == "ne_cochange", "classification"] = CNET.EIGEN.LABEL
                    df_violin[df_violin[["classification"]] == "nh_cochange", "classification"] = CNET.HIER.LABEL
                    df_violin[df_violin[["classification"]] == "nd_issue", "classification"] = INET.DEGREE.LABEL
                    df_violin[df_violin[["classification"]] == "ne_issue", "classification"] = INET.EIGEN.LABEL
                    df_violin[df_violin[["classification"]] == "nh_issue", "classification"] = INET.HIER.LABEL
                    df_violin[df_violin[["classification"]] == "nd_co_is", "classification"] = CINET.DEGREE.LABEL
                    df_violin[df_violin[["classification"]] == "ne_co_is", "classification"] = CINET.EIGEN.LABEL
                    df_violin[df_violin[["classification"]] == "nh_co_is", "classification"] = CINET.HIER.LABEL
                    df_violin <- df_violin %>%
                        mutate( classification=factor(classification,levels=c(CC.LABEL, LOC.LABEL, CNET.DEGREE.LABEL, CNET.EIGEN.LABEL, CNET.HIER.LABEL,
                                                                              INET.DEGREE.LABEL, INET.EIGEN.LABEL, INET.HIER.LABEL ,
                                                                              CINET.DEGREE.LABEL, CINET.EIGEN.LABEL, CINET.HIER.LABEL)) )

                    df_violin[["casestudy"]] = sapply(df_violin[["casestudy"]], adjust.string)

                    graph <- ggplot(data = df_violin, aes(x = start_date))

                    yaxis <- 'Ground Truth developers not part of classifications'
                    if (relative) {
                        yaxis <- 'Percentage of Ground Truth developers not part of classifications'
                    }
                    graph <- graph + xlab('Classification Method') + ylab(yaxis) +
                        #    expand_limits(y = c(0, 1.0)) +
                        theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1, size = 7), axis.text.y = element_text(size = 7), plot.title = element_text(size = 10),
                              legend.text = element_text(size = 7), legend.title = element_text(size = 7),
                              legend.key.size = unit(0.25, "cm"), legend.position = "top", axis.title.x = element_blank())

                    # start with generating plots for each casestudy individually
                    for (casestudy in available.casestudies) {

                        df_violin_casestudy = df_violin[df_violin[["casestudy"]] == adjust.string(casestudy), ]

                        graph_byClassification <- graph +
                            geom_violin(data = df_violin_casestudy, aes(y = value, x = classification), position = position_dodge(width = 0.75), width = 1) +
                            geom_boxplot(data = df_violin_casestudy, aes(y = value, x = classification, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                            ggtitle(paste(adjust.string(casestudy), adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(NETWORKS.AUTHORS), sep = "   "))

                        for (device in devices) {
                            device.name = device
                            if (device == 'tikz') device = tikzDevice::tikz
                            ggsave(sprintf("%s_gt_%sdevs_not_part_of_classification_%s.%s", file.path(plot.path.individual, paste(casestudy, "GtDevsNotPart", relative_string, sd, gt, comparison_set, sep = "_")), relative_string, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
                        }
                    }

                    # start with generating plots for all casestudies together
                    graph_byClassification <- graph +
                        geom_violin(data = df_violin, aes(y = value, x = classification), position = position_dodge(width = 0.75), width = 1) +
                        geom_boxplot(data = df_violin, aes(y = value, x = classification, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                        facet_wrap(~ casestudy) +
                        ggtitle(paste(adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(NETWORKS.AUTHORS), sep = "   "))

                    for (device in devices) {
                        device.name = device
                        if (device == 'tikz') device = tikzDevice::tikz
                        ggsave(sprintf("%s_gt_%sdevs_not_part_of_classification_%s.%s", file.path(plot.path.individual, paste("allProjects", "GtDevsNotPart", relative_string, sd, gt, comparison_set, sep = "_")), relative_string, DISCRETISATION.NAME, device.name), device = device)
                    }
                }

            }
        }
    }
}

plot.sizes.of.gt.and.classified.classes <- function(devices, list.of.casestudies, sd) {
    plot.path = file.path(OUTPUT.PATH, "overall-plots", DISCRETISATION.NAME)
    dir.create(plot.path, showWarnings = FALSE, recursive = TRUE)

    for (ground.truth in GROUND_TRUTHS) {
        for (compute_gt_set in COMPUTE_GT_SET) {

            gt = paste("GT", ground.truth, sep="-")
            comparison_set = paste("ComparisonSet", compute_gt_set, sep="-")

            gt.sizes.data = data.frame()
            core.sizes.data = data.frame()
            peripheral.sizes.data = data.frame()
            plot.path.individual = file.path(plot.path, gt, comparison_set, "sizes")
            dir.create(plot.path.individual, showWarnings = FALSE, recursive = TRUE)

            available.casestudies = c()

            for (casestudy in list.of.casestudies) {
                data.path =  file.path(OUTPUT.PATH, casestudy, DISCRETISATION.NAME, "similarity", "evaluation-results", gt, comparison_set)

                # read gt size
                gt_sizes_file = file.path(data.path,
                                          paste0("gt_size_", sd, "_", casestudy, "_", TIME.PERIOD, ifelse(SLIDING.WINDOW, "_slidingWindow_", "_"), NETWORKS.AUTHORS, "_",
                                                 gt, "_", comparison_set, ".csv"))

                # read core size
                core_sizes_file = file.path(data.path,
                                            paste0("core_size_", sd, "_", casestudy, "_", TIME.PERIOD, ifelse(SLIDING.WINDOW, "_slidingWindow_", "_"), NETWORKS.AUTHORS, "_",
                                                   gt, "_", comparison_set, ".csv"))

                # read peripheral size
                peripheral_sizes_file = file.path(data.path,
                                                  paste0("peripheral_size_", sd, "_", casestudy, "_", TIME.PERIOD, ifelse(SLIDING.WINDOW, "_slidingWindow_", "_"), NETWORKS.AUTHORS, "_",
                                                          gt, "_", comparison_set, ".csv"))

                if (file.exists(gt_sizes_file) && file.exists(core_sizes_file) && file.exists(peripheral_sizes_file)) {
                    logging::loginfo(sprintf("Read file '%s'", gt_sizes_file))
                    casestudy.gt.sizes.data = read.csv(file = gt_sizes_file, check.names = FALSE) # don't replace spaces in colnames by a point
                    casestudy.gt.sizes.data[["sizes"]] = "ground truth"
                    logging::loginfo(sprintf("Read file '%s'", core_sizes_file))
                    casestudy.core.sizes.data = read.csv(file = core_sizes_file, check.names = FALSE) # don't replace spaces in colnames by a point
                    casestudy.core.sizes.data[["sizes"]] = "classified as core"
                    logging::loginfo(sprintf("Read file '%s'", peripheral_sizes_file))
                    casestudy.peripheral.sizes.data = read.csv(file = peripheral_sizes_file, check.names = FALSE) # don't replace spaces in colnames by a point
                    casestudy.peripheral.sizes.data[["sizes"]] = "classified as peripheral"

                    gt.sizes.data = rbind(gt.sizes.data, casestudy.gt.sizes.data)
                    core.sizes.data = rbind(core.sizes.data, casestudy.core.sizes.data)
                    peripheral.sizes.data = rbind(peripheral.sizes.data, casestudy.peripheral.sizes.data)
                    available.casestudies = c(available.casestudies, casestudy)
                }
            }
            write.csv(gt.sizes.data, file = file.path(plot.path.individual, paste("gt_sizes", gt, comparison_set, sd, "overall-data.csv", sep = "_")))
            write.csv(core.sizes.data, file = file.path(plot.path.individual, paste("core_sizes", gt, comparison_set, sd, "overall-data.csv", sep = "_")))
            write.csv(peripheral.sizes.data, file = file.path(plot.path.individual, paste("peripheral_sizes", gt, comparison_set, sd, "overall-data.csv", sep = "_")))

            if (length(available.casestudies > 0)) {

                # combine gt sizes, core sizes and peripheral sizes into one data frame
                data = rbind(gt.sizes.data, core.sizes.data, peripheral.sizes.data)


                df_violin = data
                df_violin[df_violin[["classification"]] == "cc_cochange", "classification"] = CC.LABEL
                df_violin[df_violin[["classification"]] == "loc_cochange", "classification"] = LOC.LABEL
                df_violin[df_violin[["classification"]] == "nd_cochange", "classification"] = CNET.DEGREE.LABEL
                df_violin[df_violin[["classification"]] == "ne_cochange", "classification"] = CNET.EIGEN.LABEL
                df_violin[df_violin[["classification"]] == "nh_cochange", "classification"] = CNET.HIER.LABEL
                df_violin[df_violin[["classification"]] == "nd_issue", "classification"] = INET.DEGREE.LABEL
                df_violin[df_violin[["classification"]] == "ne_issue", "classification"] = INET.EIGEN.LABEL
                df_violin[df_violin[["classification"]] == "nh_issue", "classification"] = INET.HIER.LABEL
                df_violin[df_violin[["classification"]] == "nd_co_is", "classification"] = CINET.DEGREE.LABEL
                df_violin[df_violin[["classification"]] == "ne_co_is", "classification"] = CINET.EIGEN.LABEL
                df_violin[df_violin[["classification"]] == "nh_co_is", "classification"] = CINET.HIER.LABEL
                df_violin <- df_violin %>%
                    mutate( classification=factor(classification,levels=c(CC.LABEL, LOC.LABEL, CNET.DEGREE.LABEL, CNET.EIGEN.LABEL, CNET.HIER.LABEL,
                                                                          INET.DEGREE.LABEL, INET.EIGEN.LABEL, INET.HIER.LABEL ,
                                                                          CINET.DEGREE.LABEL, CINET.EIGEN.LABEL, CINET.HIER.LABEL)) )
                df_violin <- df_violin %>%
                    mutate( sizes=factor(sizes,levels=c("ground truth", "classified as core", "classified as peripheral") ))
                df_violin[["casestudy"]] = sapply(df_violin[["casestudy"]], adjust.string)

                # names(df_violin)[names(df_violin) == "start_date"] = "start date"
                # names(df_violin)[names(df_violin) == "simplify.directed"] = "simplified.directed"
                # names(df_violin)[names(df_violin) == "Ground_Truth"] = "Ground Truth"
                # names(df_violin)[names(df_violin) == "similarity metric"] = "similarity metric"
                # names(df_violin)[names(df_violin) == "compute_set"] = "comparison set"
                # names(df_violin)[names(df_violin) == "classification"] = "classificationt"
                # names(df_violin)[names(df_violin) == "value"] = "value"
                # names(df_violin)[names(df_violin) == "casestudy"] = "project"

                graph <- ggplot(data = df_violin, aes(x = start_date))

                graph <- graph + xlab('Classification Method') + ylab('Size of Set \n (number of developers in set)') +
                    #    expand_limits(y = c(0, 1.0)) +
                    theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1, size = 7), axis.text.y = element_text(size = 7), plot.title = element_text(size = 10),
                          legend.text = element_text(size = 7), legend.title = element_blank(), #element_text(size = 7),
                          legend.key.size = unit(0.25, "cm"), legend.position = "top", axis.title.x = element_blank())

                # start with generating plots for each casestudy individually
                for (casestudy in available.casestudies) {

                    df_violin_casestudy = df_violin[df_violin[["casestudy"]] == adjust.string(casestudy), ]

                    graph_byClassification <- graph +
                        geom_violin(data = df_violin_casestudy, aes(y = value, x = classification, color = sizes), position = position_dodge(width = 0.75), width = 1) +
                        geom_boxplot(data = df_violin_casestudy, aes(y = value, x = classification, color = sizes, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                        ggtitle(paste(adjust.string(casestudy), adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))

                    for (device in devices) {
                        device.name = device
                        if (device == 'tikz') device = tikzDevice::tikz
                        ggsave(sprintf("%s_byClassification_%s.%s", file.path(plot.path.individual, paste(casestudy, "Sizes", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
                    }

                    graph_bySets <- graph +
                        geom_violin(data = df_violin_casestudy, aes(y = value, x = sizes, color = classification), position = position_dodge(width = 0.75), width = 1) +
                        geom_boxplot(data = df_violin_casestudy, aes(y = value, x = sizes, color = classification, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                        ggtitle(paste(adjust.string(casestudy), adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))

                    for (device in devices) {
                        device.name = device
                        if (device == 'tikz') device = tikzDevice::tikz
                        ggsave(sprintf("%s_bySets_%s.%s", file.path(plot.path.individual, paste(casestudy, "Sizes", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
                    }

                    graph_byClassificationSeparateSets <- graph +
                        geom_violin(data = df_violin_casestudy, aes(y = value, x = classification, color = classification), position = position_dodge(width = 0.75), width = 1) +
                        geom_boxplot(data = df_violin_casestudy, aes(y = value, x = classification, color = classification, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                        facet_wrap(~ sizes) +
                        ggtitle(paste(adjust.string(casestudy), adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))

                    for (device in devices) {
                        device.name = device
                        if (device == 'tikz') device = tikzDevice::tikz
                        ggsave(sprintf("%s_byClassificationSeparateSets_%s.%s", file.path(plot.path.individual, paste(casestudy, "Sizes", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
                    }
                }

                # start with generating plots for all casestudies together
                graph_byClassification <- graph +
                    geom_violin(data = df_violin, aes(y = value, x = classification, color = sizes), position = position_dodge(width = 0.75), width = 1) +
                    geom_boxplot(data = df_violin, aes(y = value, x = classification, color = sizes, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                    facet_wrap(~ casestudy, scales = "free_y") +
                    ggtitle(paste(adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))

                for (device in devices) {
                    device.name = device
                    if (device == 'tikz') device = tikzDevice::tikz
                    ggsave(sprintf("%s_byClassification_%s.%s", file.path(plot.path.individual, paste("allProjects", "Sizes", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name), device = device)
                }

                graph_bySets <- graph +
                    geom_violin(data = df_violin, aes(y = value, x = sizes, color = classification), position = position_dodge(width = 0.75), width = 1) +
                    geom_boxplot(data = df_violin, aes(y = value, x = sizes, color = classification, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                    facet_wrap(~ casestudy, scales = "free_y") +
                    ggtitle(paste(adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))

                for (device in devices) {
                    device.name = device
                    if (device == 'tikz') device = tikzDevice::tikz
                    ggsave(sprintf("%s_bySets_%s.%s", file.path(plot.path.individual, paste("allProjects", "Sizes", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name), device = device)
                }

                graph_byClassificationSeparateSets <- graph +
                    geom_violin(data = df_violin, aes(y = value, x = classification, color = classification), position = position_dodge(width = 0.75), width = 1) +
                    geom_boxplot(data = df_violin, aes(y = value, x = classification, color = classification, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
                    #facet_wrap(~ sizes) +
                    facet_wrap(casestudy ~ sizes) +
                    ggtitle(paste(adjust.string(TIME.PERIOD), adjust.string(ifelse(SLIDING.WINDOW, "sliding window", "")), adjust.string(sd), adjust.string(NETWORKS.AUTHORS), sep = "   "))

                for (device in devices) {
                    device.name = device
                    if (device == 'tikz') device = tikzDevice::tikz
                    ggsave(sprintf("%s_byClassificationSeparateSets_%s.%s", file.path(plot.path.individual, paste("allProjects", "Sizes", sd, gt, comparison_set, sep = "_")), DISCRETISATION.NAME, device.name), device = device)
                }
            }
        }
    }
}

plot.times.between.write.permission.events <- function(devices, list.of.casestudies, include.extended.events = FALSE) {
    plot.path = file.path(OUTPUT.PATH, "overall-plots", "time_diff_between_events")
    dir.create(plot.path, showWarnings = FALSE, recursive = TRUE)

    available.casestudies = c()
    time.diff.data = data.frame()

    name.string = "write"
    output.string = "privileged"
    title.string = "Privileged"
    if (include.extended.events) {
        name.string = "writeAndExtended"
        output.string = "privilegedAndExtended"
        title.string = "Privileged and Extended"
    }

    for (casestudy in list.of.casestudies) {
        data.path =  file.path(OUTPUT.PATH, casestudy)

        casestudy.timediff.file = file.path(data.path, sprintf("differences_between_a_developers_%s_permission_events.rds", name.string))

        if (file.exists(casestudy.timediff.file)) {
            logging::loginfo(sprintf("Read file '%s'", casestudy.timediff.file))
            casestudy.data = unlist(readRDS(file = casestudy.timediff.file))

            # convert to days
            casestudy.data = casestudy.data / 60 / 60 / 24

            # print median time difference:
            logging::loginfo(paste("MEDIAN TIME DIFFERENCE:", casestudy, median(as.numeric(casestudy.data)), "days"))
            logging::loginfo(paste("MAXIMUM TIME DIFFERENCE:", casestudy, max(as.numeric(casestudy.data)), "days"))

            casestudy.data.df = cbind(casestudy.data, casestudy)
            available.casestudies = c(available.casestudies, casestudy)

            time.diff.data = rbind(time.diff.data, casestudy.data.df)
        }
    }
    colnames(time.diff.data) = c("value", "casestudy")
    time.diff.data[["value"]] = as.numeric(time.diff.data[["value"]])
    time.diff.data[["casestudy"]] = sapply(time.diff.data[["casestudy"]], adjust.string)

    # print median time difference:
    logging::loginfo(paste("MEDIAN TIME DIFFERENCE:", "all projects", median(time.diff.data[["value"]]), "days"))
    logging::loginfo(paste("MAXIMUM TIME DIFFERENCE:", "all projects", max(time.diff.data[["value"]]), "days"))

    graph <- ggplot(data = time.diff.data) #data = time.diff.data)

    graph <- graph + xlab('Projects') + ylab(paste0("Time Diff ", title.string, " Events \n (days)")) +
        #    expand_limits(y = c(0, 1.0)) +
        theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1, size = 7), axis.text.y = element_text(size = 7), plot.title = element_text(size = 10),
              legend.text = element_text(size = 7), legend.title = element_text(size = 7),
              legend.key.size = unit(0.25, "cm"), legend.position = "top")

    # start with generating plots for all casestudies together
    graph_byCasestudy <- graph +
        geom_violin(data = time.diff.data, aes(y = value, x = casestudy), position = position_dodge(width = 0.75), width = 1) +
        geom_boxplot(data = time.diff.data, aes(y = value, x = casestudy, fatten = 0.0001), position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
        #facet_wrap(~ casestudy) +
        ggtitle(paste0("Time Differences between ", title.string, " Events"))

    for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%s_time_diff_between_%s_events_days.%s", file.path(plot.path, "allProjects"), output.string, device.name), device = device)
    }

    graph_byCasestudy_withoutOutliers = graph_byCasestudy + coord_cartesian(ylim = c(0,7)) + ylab(paste0("Time Diff ", title.string, " Events \n (days) \n (outliers cutted at 7 days)"))

    for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%s_time_diff_between_%s_events_days_without_outliers_one_week.%s", file.path(plot.path, "allProjects"), output.string, device.name), device = device)
    }

    graph_byCasestudy_withoutOutliers = graph_byCasestudy + coord_cartesian(ylim = c(0,14)) + ylab(paste0("Time Diff ", title.string, " Events \n (days) \n (outliers cutted at 14 days)"))

    for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%s_time_diff_between_%s_events_days_without_outliers_two_weeks.%s", file.path(plot.path, "allProjects"), output.string, device.name), device = device)
    }

    graph_byCasestudy_withoutOutliers = graph_byCasestudy + coord_cartesian(ylim = c(0,25)) + ylab(paste0("Time Diff ", title.string, "Events \n (days) \n (outliers cutted at 25 days)"))

    for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%s_time_diff_between_%s_events_days_without_outliers_25_days.%s", file.path(plot.path, "allProjects"), output.string, device.name), device = device)
    }

    graph_byCasestudy_withoutOutliers = graph_byCasestudy + coord_cartesian(ylim = c(0,30)) + ylab(paste0("Time Diff ", title.string, " Events \n (days) \n (outliers cutted at 30 days)"))

    for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%s_time_diff_between_%s_events_days_without_outliers_one_month.%s", file.path(plot.path, "allProjects"), output.string, device.name), device = device)
    }

}

plot.covered.permission.events.by.time <- function(devices, list.of.casestudies, time.ranges, developer.based = NULL, include.extended.events = FALSE) {
    plot.path = file.path(OUTPUT.PATH, "overall-plots", "time_diff_between_events")
    dir.create(plot.path, showWarnings = FALSE, recursive = TRUE)

    available.casestudies = c()
    time.diff.data = data.frame()

    name.string = "write"
    output.string = "privileged"
    title.string = "Privileged"
    if (include.extended.events) {
        name.string = "writeAndExtended"
        output.string = "privilegedAndExtended"
        title.string = "Privileged and Extended"
    }
    if (developer.based == "max") {
        output.string = paste0("maxDeveloperBased_", output.string)
    } else if (developer.based == "median"){
        output.string = paste0("medianDeveloperBased_", output.string)
    }

    for (casestudy in list.of.casestudies) {
        data.path =  file.path(OUTPUT.PATH, casestudy)

        casestudy.timediff.file = file.path(data.path, sprintf("differences_between_a_developers_%s_permission_events.rds", name.string))

        if (file.exists(casestudy.timediff.file)) {
            logging::loginfo(sprintf("Read file '%s'", casestudy.timediff.file))

            if (developer.based == "max") {
                casestudy.data = unlist(lapply(readRDS(file = casestudy.timediff.file), max))
                # remove one-time event users (they lead to errors as no value is available)
                casestudy.data = casestudy.data[casestudy.data >= 0 & !is.na(casestudy.data)]
            } else if (developer.based == "median") {
                casestudy.data = unlist(lapply(readRDS(file = casestudy.timediff.file), median))
                # remove one-time event users (they lead to errors as no value is available)
                casestudy.data = casestudy.data[casestudy.data >= 0 & !is.na(casestudy.data)]
            } else {
                casestudy.data = unlist(readRDS(file = casestudy.timediff.file))
            }

            # convert to days
            casestudy.data = casestudy.data / 60 / 60 / 24

            percent.of.captured.events = data.frame()

            for (window.length in time.ranges) {
                time.difference.in.time.range = lubridate::duration(days = as.numeric(casestudy.data)) < lubridate::duration(window.length)
                percentage.data = c(window.length, casestudy, sum(time.difference.in.time.range) / length(time.difference.in.time.range))
                percent.of.captured.events = rbind(percent.of.captured.events, percentage.data)
                colnames(percent.of.captured.events) = c("window length", "casestudy", "percentage")
            }

            available.casestudies = c(available.casestudies, casestudy)
            time.diff.data = rbind(time.diff.data, percent.of.captured.events)

        }
    }

    time.diff.data <- time.diff.data %>%
        mutate( `window length`=factor(`window length`,levels=time.ranges) )
    time.diff.data[["percentage"]] = as.numeric(time.diff.data[["percentage"]])
    time.diff.data[["casestudy"]] = sapply(time.diff.data[["casestudy"]], adjust.string)

    if (developer.based == "max") {
        title = paste0("Covered Ground Truth Developers \n according to their Max. Time Diff \n between ", title.string, " Events")
    } else if (developer.based == "median") {
        title = paste0("Covered Ground Truth Developers \n according to their Median Time Diff \n between ", title.string, " Events")
    } else {
        title = paste0("Covered Time Diffs \n between", title.string, " Events")
    }

    casestudy.colors = colorRampPalette(brewer.pal(8, "Set1"))(length(available.casestudies))

    graph <- ggplot(data = time.diff.data) #data = time.diff.data)

    graph <- graph + xlab('Projects') + ylab(title) +
        #    expand_limits(y = c(0, 1.0)) +
        theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1, size = 7), axis.text.y = element_text(size = 7), plot.title = element_text(size = 10),
              legend.text = element_text(size = 7), legend.title = element_text(size = 7),
              legend.key.size = unit(0.25, "cm"), legend.position = "none")

    # start with generating plots for all casestudies together
    graph_byCasestudy <- graph +
        #geom_violin(data = time.diff.data, aes(y = percentage, x = `window length`), position = position_dodge(width = 0.75), width = 1) +
        geom_col(data = time.diff.data, aes( x = casestudy, y = percentage, fill=casestudy, fatten = 0.0001), outlier.shape = NA) + #, position = position_dodge(width = 0.75), width = 0.2, outlier.shape = NA) +
        #scale_fill_brewer(palette="Set1") +
        scale_fill_manual(values = casestudy.colors) +
        geom_text(aes(label=round(percentage, digits = 2), x=casestudy, y=percentage, vjust = 1.2), colour="white", size=1.4) +
        coord_cartesian(ylim = c(0,1)) +
        facet_wrap(~ `window length`, nrow = 1 ) +
        ggtitle(title)

    for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        if (developer.based == "max" || developer.based == "median") {
            ggsave(sprintf("%s_covered_developers_by_%s_time_between_events_%s.%s", file.path(plot.path, "allProjects"), developer.based, output.string, device.name), device = device,
                   height = 3, width = 12)
        } else {
            ggsave(sprintf("%s_covered_permission_events_by_time_%s.%s", file.path(plot.path, "allProjects"), output.string, device.name), device = device,
                   height = 3, width = 12)
        }

    }
}

plot.cumulative.distribution.of.events.by.time <- function(devices, list.of.casestudies, developer.based = NULL, include.extended.events = FALSE) {
    plot.path = file.path(OUTPUT.PATH, "overall-plots", "time_diff_between_events")
    dir.create(plot.path, showWarnings = FALSE, recursive = TRUE)

    available.casestudies = c()
    time.diff.for.cumulative.distribution.function = data.frame()

    name.string = "write"
    output.string = "privileged"
    title.string = "Priviliged"
    if (include.extended.events) {
        name.string = "writeAndExtended"
        output.string = "privilegedAndExtended"
        title.string = "Privileged and Extended"
    }
    if (developer.based == "max") {
        output.string = paste0("maxDeveloperBased_", output.string)
    } else if (developer.based == "median"){
        output.string = paste0("medianDeveloperBased_", output.string)
    } else if (developer.based == "avg"){
        output.string = paste0("avgDeveloperBased_", output.string)
    }

    for (casestudy in list.of.casestudies) {
        data.path =  file.path(OUTPUT.PATH, casestudy)

        casestudy.timediff.file = file.path(data.path, sprintf("differences_between_a_developers_%s_permission_events.rds", name.string))

        if (file.exists(casestudy.timediff.file)) {
            logging::loginfo(sprintf("Read file '%s'", casestudy.timediff.file))

            if (developer.based == "max") {
                casestudy.data = unlist(lapply(readRDS(file = casestudy.timediff.file), max))
                # remove one-time event users (they lead to errors as no value is available)
                casestudy.data = casestudy.data[casestudy.data >= 0 & !is.na(casestudy.data)]
            } else if (developer.based == "median") {
                casestudy.data = unlist(lapply(readRDS(file = casestudy.timediff.file), median))
                # remove one-time event users (they lead to errors as no value is available)
                casestudy.data = casestudy.data[casestudy.data >= 0 & !is.na(casestudy.data)]
            }else if (developer.based == "avg") {
                casestudy.data = unlist(lapply(readRDS(file = casestudy.timediff.file), mean))
                # remove one-time event users (they lead to errors as no value is available)
                casestudy.data = casestudy.data[casestudy.data >= 0 & !is.na(casestudy.data)]
            } else {
                casestudy.data = unlist(readRDS(file = casestudy.timediff.file))
            }

            # convert to days
            casestudy.data = casestudy.data / 60 / 60 / 24

            # cumulative distribution function
            time.diff.for.cumulative.distribution.function = rbind(time.diff.for.cumulative.distribution.function, data.frame(diff = casestudy.data, casestudy = casestudy))

            available.casestudies = c(available.casestudies, casestudy)
        }
    }
    time.diff.for.cumulative.distribution.function[["casestudy"]] = sapply(time.diff.for.cumulative.distribution.function[["casestudy"]], adjust.string)

    if (developer.based == "max") {
        title = paste0("Max. Time Difference between ", title.string, " Events per Developer (days)")
    } else if (developer.based == "median") {
        title = paste0("Median Time Difference between ", title.string, " Events per Developer (days)")
    } else if (developer.based == "avg") {
        title = paste0("Avg. Time Difference between ", title.string, " Events per Developer (days)")
    } else {
        title = paste0("Time Difference between ", title.string, " Events of a Developer (days)")
    }

    casestudy.colors = colorRampPalette(brewer.pal(8, "Set1"))(length(available.casestudies))

    fontsize.original = NULL

    for (device in devices) {
        device.name = device
        if (device == 'tikz') {
            device = tikzDevice::tikz
            fontsize = 27 #fontsize.original * 1.5
        } else {
            fontsize = fontsize.original
        }

        # plot cumulative distribution for 3 months:
        ggplot(time.diff.for.cumulative.distribution.function, aes(diff, color=casestudy)) + stat_ecdf(geom = "step", pad = TRUE) + # "point"
            coord_cartesian(xlim = c(10,103)) + #  (0,93)
            theme(legend.title = element_blank(), legend.position = "none", text = element_text(size = fontsize)) + #               legend.key.size = unit(0.25, "cm"),
            # ggtitle("") +
            xlab(title) +
            ylab("Cumulative Distribution") +
            geom_vline(xintercept = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, y = 0.04, label = "3 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, y = 0.04, label = "6 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, y = 0.04, label = "9 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, y = 0.04, label = "12 months", size = fontsize / .pt - 2) +
            scale_color_manual(values = casestudy.colors) +
            guides(color=guide_legend(nrow=2))


        if (developer.based == "max" || developer.based == "median" || developer.based == "avg") {
            ggsave(sprintf("%s_cumulative-distribution_developers_by_%s_time_between_events_3months_%s.%s", file.path(plot.path, "allProjects"), developer.based, output.string, device.name), device = device,
                   height = 3, width = 12)
        } else {
            ggsave(sprintf("%s_cumulative-distribution_permission_events_by_time_3months_%s.%s", file.path(plot.path, "allProjects"), output.string, device.name), device = device,
                   height = 3, width = 12)
        }


        # plot cumulative distribution:
        ggplot(time.diff.for.cumulative.distribution.function, aes(diff, color=casestudy)) + stat_ecdf(geom = "step", pad = TRUE) + # "point"
            coord_cartesian(xlim = c(10,193)) + # (0,183)
            theme(legend.title = element_blank(), legend.position = "none", text = element_text(size = fontsize)) + #               legend.key.size = unit(0.25, "cm"),
            # ggtitle("") +
            xlab(title) +
            ylab("Cumulative Distribution") +
            geom_vline(xintercept = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, y = 0.04, label = "3 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, y = 0.04, label = "6 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, y = 0.04, label = "9 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, y = 0.04, label = "12 months", size = fontsize / .pt - 2) +
            scale_color_manual(values = casestudy.colors) +
            guides(color=guide_legend(nrow=2))

        if (developer.based == "max" || developer.based == "median" || developer.based == "avg") {
            ggsave(sprintf("%s_cumulative-distribution_developers_by_%s_time_between_events_6months_%s.%s", file.path(plot.path, "allProjects"), developer.based, output.string, device.name), device = device,
                   height = 3, width = 12)
        } else {
            ggsave(sprintf("%s_cumulative-distribution_permission_events_by_time_6months_%s.%s", file.path(plot.path, "allProjects"), output.string, device.name), device = device,
                   height = 3, width = 12)
        }

        # plot cumulative distribution:
        ggplot(time.diff.for.cumulative.distribution.function, aes(diff, color=casestudy)) + stat_ecdf(geom = "step", pad = TRUE) + # "point"
            coord_cartesian(xlim = c(10,290)) + # (0, 280)
            theme(legend.title = element_blank(), legend.position = "none", text = element_text(size = fontsize)) + #               legend.key.size = unit(0.25, "cm"),
            # ggtitle("") +
            xlab(title) +
            ylab("Cumulative Distribution") +
            geom_vline(xintercept = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, y = 0.04, label = "3 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, y = 0.04, label = "6 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, y = 0.04, label = "9 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, y = 0.04, label = "12 months", size = fontsize / .pt - 2) +
            scale_color_manual(values = casestudy.colors) +
            guides(color=guide_legend(nrow=2))

        if (developer.based == "max" || developer.based == "median" || developer.based == "avg") {
            ggsave(sprintf("%s_cumulative-distribution_developers_by_%s_time_between_events_9months_%s.%s", file.path(plot.path, "allProjects"), developer.based, output.string, device.name), device = device,
                   height = 3, width = 12)
        } else {
            ggsave(sprintf("%s_cumulative-distribution_permission_events_by_time_9months_%s.%s", file.path(plot.path, "allProjects"), output.string, device.name), device = device,
                   height = 3, width = 12)
        }

        # plot cumulative distribution:
        ggplot(time.diff.for.cumulative.distribution.function, aes(diff, color=casestudy)) + stat_ecdf(geom = "step", pad = TRUE) +# "point"
            coord_cartesian(xlim = c(10,376), expand = c(0.01,0.1)) + # (0, 366)
            theme(legend.title = element_blank(), legend.position = "none", text = element_text(size = fontsize)) + #               legend.key.size = unit(0.25, "cm"),
            # ggtitle("") +
            xlab(title) +
            ylab("Cumulative Distribution") +
            geom_vline(xintercept = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, y = 0.04, label = "3 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, y = 0.04, label = "6 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, y = 0.04, label = "9 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, y = 0.04, label = "12 months", size = fontsize / .pt - 2) +
            scale_color_manual(values = casestudy.colors) +
            guides(color=guide_legend(nrow=2))

        if (developer.based == "max" || developer.based == "median" || developer.based == "avg") {
            ggsave(sprintf("%s_cumulative-distribution_developers_by_%s_time_between_events_12months_%s.%s", file.path(plot.path, "allProjects"), developer.based, output.string, device.name), device = device,
                   height = 4, width = 13)
        } else {
            ggsave(sprintf("%s_cumulative-distribution_permission_events_by_time_12months_%s.%s", file.path(plot.path, "allProjects"), output.string, device.name), device = device,
                   height = 4, width = 13)
        }

        # plot faceted:

        # plot cumulative distribution for 3 months:
        ggplot(time.diff.for.cumulative.distribution.function, aes(diff, color=casestudy)) + stat_ecdf(geom = "step", pad = TRUE) + # "point"
            coord_cartesian(xlim = c(10,103)) + #  (0,93)
            theme(legend.title = element_blank(), legend.position = "none", text = element_text(size = fontsize)) + #               legend.key.size = unit(0.25, "cm"),
            # ggtitle("") +
            xlab(title) +
            ylab("Cumulative Distribution") +
            geom_vline(xintercept = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, y = 0.04, label = "3 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, y = 0.04, label = "6 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, y = 0.04, label = "9 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, y = 0.04, label = "12 months", size = fontsize / .pt - 2) +
            scale_color_manual(values = casestudy.colors) +
            facet_wrap(~ casestudy) +
            guides(color=guide_legend(nrow=2))

        if (developer.based == "max" || developer.based == "median" || developer.based == "avg") {
            ggsave(sprintf("%s_cumulative-distribution_developers_by_%s_time_between_events_3months_%s.%s", file.path(plot.path, "allProjects_faceted"), developer.based, output.string, device.name), device = device,
                   height = 12, width = 12)
        } else {
            ggsave(sprintf("%s_cumulative-distribution_permission_events_by_time_3months_%s.%s", file.path(plot.path, "allProjects_faceted"), output.string, device.name), device = device,
                   height = 12, width = 12)
        }

        # plot cumulative distribution:
        ggplot(time.diff.for.cumulative.distribution.function, aes(diff, color=casestudy)) + stat_ecdf(geom = "step", pad = TRUE) + # "point"
            coord_cartesian(xlim = c(10,193)) + # (0,183)
            theme(legend.title = element_blank(), legend.position = "none", text = element_text(size = fontsize)) + #               legend.key.size = unit(0.25, "cm"),
            # ggtitle("") +
            xlab(title) +
            ylab("Cumulative Distribution") +
            geom_vline(xintercept = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, y = 0.04, label = "3 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, y = 0.04, label = "6 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, y = 0.04, label = "9 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, y = 0.04, label = "12 months", size = fontsize / .pt - 2) +
            scale_color_manual(values = casestudy.colors) +
            facet_wrap(~ casestudy) +
            guides(color=guide_legend(nrow=2))

        if (developer.based == "max" || developer.based == "median" || developer.based == "avg") {
            ggsave(sprintf("%s_cumulative-distribution_developers_by_%s_time_between_events_6months_%s.%s", file.path(plot.path, "allProjects_faceted"), developer.based, output.string, device.name), device = device,
                   height = 12, width = 12)
        } else {
            ggsave(sprintf("%s_cumulative-distribution_permission_events_by_time_6months_%s.%s", file.path(plot.path, "allProjects_faceted"), output.string, device.name), device = device,
                   height = 12, width = 12)
        }

        # plot cumulative distribution:
        ggplot(time.diff.for.cumulative.distribution.function, aes(diff, color=casestudy)) + stat_ecdf(geom = "step", pad = TRUE) + # "point"
            coord_cartesian(xlim = c(10,290)) + # (0, 280)
            theme(legend.title = element_blank(), legend.position = "none", text = element_text(size = fontsize)) + #               legend.key.size = unit(0.25, "cm"),
            # ggtitle("") +
            xlab(title) +
            ylab("Cumulative Distribution") +
            geom_vline(xintercept = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, y = 0.04, label = "3 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, y = 0.04, label = "6 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, y = 0.04, label = "9 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, y = 0.04, label = "12 months", size = fontsize / .pt - 2) +
            scale_color_manual(values = casestudy.colors) +
            facet_wrap(~ casestudy) +
            guides(color=guide_legend(nrow=2))

        if (developer.based == "max" || developer.based == "median" || developer.based == "avg") {
            ggsave(sprintf("%s_cumulative-distribution_developers_by_%s_time_between_events_9months_%s.%s", file.path(plot.path, "allProjects_faceted"), developer.based, output.string, device.name), device = device,
                   height = 12, width = 12)
        } else {
            ggsave(sprintf("%s_cumulative-distribution_permission_events_by_time_9months_%s.%s", file.path(plot.path, "allProjects_faceted"), output.string, device.name), device = device,
                   height = 12, width = 12)
        }

        # plot cumulative distribution:
        ggplot(time.diff.for.cumulative.distribution.function, aes(diff, color=casestudy)) + stat_ecdf(geom = "step", pad = TRUE) +# "point"
            coord_cartesian(xlim = c(10,376), expand = c(0.01,0.1)) + # (0, 366)
            theme(legend.title = element_blank(), legend.position = "none", text = element_text(size = fontsize)) + #               legend.key.size = unit(0.25, "cm"),
            # ggtitle("") +
            xlab(title) +
            ylab("Cumulative Distribution") +
            geom_vline(xintercept = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("3months")) / 60 / 60 / 24, y = 0.04, label = "3 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("6months")) / 60 / 60 / 24, y = 0.04, label = "6 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("9months")) / 60 / 60 / 24, y = 0.04, label = "9 months", size = fontsize / .pt - 2) +
            geom_vline(xintercept = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, linetype = "dotted", color = "black") +
            annotate("text", x = as.numeric(lubridate::duration("12months")) / 60 / 60 / 24, y = 0.04, label = "12 months", size = fontsize / .pt - 2) +
            scale_color_manual(values = casestudy.colors) +
            facet_wrap(~ casestudy) +
            guides(color=guide_legend(nrow=2))

        if (developer.based == "max" || developer.based == "median" || developer.based == "avg") {
            ggsave(sprintf("%s_cumulative-distribution_developers_by_%s_time_between_events_12months_%s.%s", file.path(plot.path, "allProjects_faceted"), developer.based, output.string, device.name), device = device,
                   height = 12, width = 12)
        } else {
            ggsave(sprintf("%s_cumulative-distribution_permission_events_by_time_12months_%s.%s", file.path(plot.path, "allProjects_faceted"), output.string, device.name), device = device,
                   height = 12, width = 12)
        }
    }
}
