## Copyright 2020 Nils Alznauer <s9nialzn@stud.uni-saarland.de>
## Copyright 2021-2022 Thomas Bock <bockthom@cs.uni-saarland.de>
## All Rights Reserved.

GROUND_TRUTHS = c(
  # "all_data",
  "issues",
  "issuesInclExtended",
  "committer"#,
  # "omc",
  # "otc",
  # "former_gt_all",
  # "former_gt_timed"
)

COMPUTE_GT_SET = c(
  "CoreClassification",
  # "LOC",
  # "CC",
  # "CC_LOC",
  # "Union",
  # "Intersect",
  "Other_GT"
)

get_available_gts <- function(){
  available_gts = c(
                  #  "all_data",
                    "issues",
                    "issuesInclExtended",
                    "committer"#,
                  #  "omc",
                  #  "otc",
                  #  "former_gt_all",
                  #  "former_gt_timed"
                   )
  return(available_gts)
}

review_committer <- function() {

  main_table <- list()
  main_table["committer"] = list(unique(c(
    # Source: https://github.com/moby/moby/blob/02bc2769fb12b617e572b166b4851fa3f908580c/MAINTAINERS (2020-07-21)

    # Core Maintainers:
    "Akihiro Suda", #akihirosuda,
    "Anusha", #anusha,
    "Lei Jitang", #coolljt0725,
    "Brian Goff", #cpuguy83,
    "Michael Crosby", #crosbymichael,
    "Phil Estes", #estesp,
    "John Stephens", #johnstep,
    "Justin Cormack", #justincormack,
    "Kir Kolyshkin", #kolyshkin,
    "John Howard", #lowenna,
    "Morgan Bauer", #mhbauer,
    "Antonio Murdaca", #runcom,
    "Stephen J Day", #Stephen Day, #stevvooe,
    "Sebastiaan van Stijn", #thajeztah,
    "Tianon Gravi", #tianon,
    "Tibor Vass", #tibor,
    "Tonis Tiigi", #tonistiigi,
    "unclejack", #unclejack,
    "Vincent Demeester", #vdemeester,
    "Victor Vieux", #vieux,
    "Yong Tang"#, #yongtang,

    # Curators:
    #"Alex Ellis", #alexellis
    #"andrewhsu", #andrewhsu
    #"Lorenzo Fontana", #fntlnz
    #"Gianluca Arbezzano", #gianarb
    #"Olli Janatuinen", #olljanat
    #"Jeff Anderson", #programmerq
    #"ripcurld00d", #ripcurld
    #"Sam Whited", #samwhited
    #"Sebastiaan van Stijn", #thajeztah

    # Alumni (maintainers no longer active on the project)
    #"Aaron Lehmann", #aaronlehmann
    #"Harald Albers", #albers
    #"Andrea Luzzardi", #aluzzardi
    #"David Calavera", #calavera
    #"Daniel Nephin", #dnephin
    #"Doug Davis", #duglin
    #"Erik Hollensbe", #erikh
    #"Evan Hazlett", #ehazlett
    #"Arnaud Porterie (icecrime)", #Arnaud Porterie, icecrime
    #"James Turnbull", #jamtur01
    #"Jess Frazelle", #Jessica Frazelle, #jessfraz
    #"Alexander Morozov", #lk4d4
    #"Madhu Venugopal", #mavenugo
    #"Kenfe-Mickael Laventure", #Kenfe-Mickaël Laventure, #mlaventure
    #"moxiegirl", # Mary Anthony, #moxiegirl
    #"Jana Radhakrishnan", #mrjana
    #"Sven Dowideit", #sven
    #"Vincent Batts", #vbatts
    #"Vishnu Kannan", #vishh

    # TSC https://github.com/moby/tsc/blob/master/MEMBERS.md
    #"Phil Estes",
    #"Laura Frank",
    #"Justin Cormack",
    #"Tianon Gravi",
    #"Arnaud Porterie (icecrime)", #Arnaud Porterie
    #"Sebastiaan van Stijn"
  )))

  return(main_table)
}

filter_issues <- function(project.data) {
  project.data$set.issues(filter(project.data$get.issues(),
                                 author.name != "GitHub"
                                 ))
  return(project.data)
}
