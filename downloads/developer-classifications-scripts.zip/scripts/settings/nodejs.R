## Copyright 2020 Nils Alznauer <s9nialzn@stud.uni-saarland.de>
## Copyright 2021-2022 Thomas Bock <bockthom@cs.uni-saarland.de>
## All Rights Reserved.

GROUND_TRUTHS = c(
  # "all_data",
  "issues",
  "issuesInclExtended",
  "committer"#,
  # "omc",
  # "otc",
  # "former_gt_all",
  # "former_gt_timed"
)

COMPUTE_GT_SET = c(
  "CoreClassification",
  # "LOC",
  # "CC",
  # "CC_LOC",
  # "Union",
  # "Intersect",
  "Other_GT"
)

get_available_gts <- function(){
  available_gts = c(
                  #  "all_data",
                    "issues",
                    "issuesInclExtended",
                    "committer"#,
                  #  "omc",
                  #  "otc",
                  #  "former_gt_all",
                  #  "former_gt_timed"
                   )
  return(available_gts)
}

review_committer <- function() {

  # create the list that will be returned
  main_table <- list()

  # add all people that are confirmed to be core developer / committer by the organization itself
  main_table["committer"] = list(unique(c(
    # Source: https://github.com/nodejs/node/tree/84819b8a679a9e4c65668af5527609a0e8626cdb (2019-11-28)

    # Technical Steering Committee
    "Anna Henningsen",
    "Anatoli Papirovski",
    "Beth Griggs",
    #"Ruben Bridgewater", (later)
    "Сковорода Никита Андреевич",
    "Colin Ihrig",
    #"Shelley Vohr", (later)
    "Daniel Bevenius",
    "Franziska Hinkelmann",
    "Fishrock123", # Jeremiah Senkpiel
    "Gabriel Schulhof",
    "Gireesh Punathil",
    "jasnell", # James M Snell
    "joyeecheung",
    "Matteo Collina",
    "Michael Dawson",
    #"Matheus Marchini", # trans, now "Mary Marchini" (later)
    "Myles Borins",
    "Sam Roberts,",
    "Michaël Zasso",
    "Sakthipriyan Vairamani (thefourtheye)",
    "Tobias Nießen",
    "Rich Trott",

    # collaborators
    #"Anna Henningsen", (also in TSC)
    #"Antoine du HAMEL", (later)
    "Aleksei Koziatinskii",
    "Andreas Madsen",
    "Anto Aravinth",
    #"Anatoli Papirovski", (also in TSC)
    "Alexey Orlenko",
    #"AshCripps", (later)
    "Benjamin Coe", # Ben Coe
    "Bryan English",
    "Benjamin Gruenbaum",
    #"Beth Griggs", (also in TSC)
    "Bradley Farias",
    "Benedikt Meurer",
    "Ben Noordhuis",
    "Christopher Hiller",
    "Ruben Bridgewater",
    "Bartosz Sosnowski",
    "Calvin Metcalf",
    "cclauss", # Christian Clauss
    #"Сковорода Никита Андреевич", (also in TSC)
    #"Colin Ihrig", (also in TSC)
    "Claudio Rodriguez",
    "Shelley Vohr",
    #"Daniel Bevenius", (also in TSC)
    "Danielle Adams",
    "Jamie Davis",
    #"Derek Lewis",
    "David Carlier",
    "Gus Caplan",
    "Hitesh Kanwathirtha",
    "Adrian Estrada",
    "Robert Jefe Lindstaedt",
    "Eugene Ostroukhov",
    "Evan Lucas",
    #"Fishrock123", # Jeremiah Senkpiel" (also in TSC)
    #"Franziska Hinkelmann", (also in TSC)
    #"Gerhard Stoebich", (later)
    #"Gabriel Schulhof", (also in TSC)
    "George Adams",
    "geek", # Wyatt Preul
    "gengjiawen",
    #"Gireesh Punathil", (also in TSC)
    #"Geoffrey Booth", (later)
    "guybedford",
    #"Harshitha KP", (later)
    "Yang Guo",
    #"himself65", # Zeyu Yang (later)
    "Yuta Hiroto",
    "Rebecca Turner",
    "Fedor Indutny",
    "Italo A. Casas",
    "Jackson Tian",
    "jasnell", # James M Snell (also in TSC)
    "Johan Bergström",
    #"joyeecheung", (also in TSC)
    "John-David Dalton",
    "Jan Krems",
    "João Reis",
    "Julian Duque",
    #"Juan José Arboleda", (later)
    "JungMinu", # Minwoo Jung
    "Kyle Farnung",
    "Lance Ball",
    #"Lucas Woo", (later)
    "Leko", # Shingo Inoue
    "Luigi Pinca",
    "Denys Otrishko",
    "Jon Moss",
    "Mathias Buus",
    #"Alba Mendez", (later)
    #"Matteo Collina", (also in TSC)
    #"Michael Dawson", (also in TSC)
    "Julien Gilli",
    "Matheus Marchini", # trans, now "Mary Marchini"
    "MoonBall", # Chen Gang
    "Brian White",
    #"Myles Borins", (also in TSC)
    "Teddy Katz",
    "Ali Ijaz Sheikh",
    "oyyd", # Ouyang Yadong
    "Prince J Wesley", # Prince John Wesley
    "Peter Marshall",
    #"Andrey Pechkurov", (later)
    "Stephen Belanger",
    "Refael Ackermann",
    "rexagod", # Pranshu Srivastava
    "Richard Lau",
    "ronkorving",
    "rickyes", # Ricky Zhou
    #"Robert Nagy", (later)
    "Sam Ruby",
    #"Ruy Adorno", (later)
    "Rod Vagg",
    "Ujjwal Sharma",
    "Saúl Ibarra Corretgé",
    #"Sam Roberts", (also in TSC)
    "Santiago Gimeno",
    "Sebastiaan Deckers",
    "Nikolai Vavilov",
    "Shigeki Ohtsu",
    "Masashi Hirano",
    "Roman Reiss",
    "Steven R. Loomis",
    "Weijia Wang",
    #"Michaël Zasso", (also in TSC)
    #"Sakthipriyan Vairamani (thefourtheye)", (also in TSC)
    #"sxa", # Stewart X Addison (later)
    "GLEN", # Glean Keane
    "Timothy Gu", # Tiancheng \"Timothy\" Gu
    #"Tobias Nießen", (also in TSC)
    "Trivikram", # Trivikram Kamat
    #"Rich Trott", (also in TSC)
    "Vladimir de Turckheim",
    "Vladimir Kurchatkin",
    "Daijiro Wachi",
    "Thomas Watson",
    "XadillaX", # Khaidi Chu
    "Yihong Wang",
    "Yorkie Lui",
    "Yosuke Furukawa",
    "zhangyongsheng"
  )))

  return(main_table)
}

filter_issues <- function(project.data) {
  project.data$set.issues(filter(project.data$get.issues(),
                                 author.name != "dependabotbot"
                                 & author.name != "github-actionsbot"
                                 & author.name != "nodejs-github-bot"
                                 & author.name != "travis-cibot"
                                 & author.name != "GitHub"
                                 ))
  return(project.data)
}
