## Copyright 2020 Nils Alznauer <s9nialzn@stud.uni-saarland.de>
## Copyright 2021-2022 Thomas Bock <bockthom@cs.uni-saarland.de>
## All Rights Reserved.

GROUND_TRUTHS = c(
  # "all_data",
  "issues",
  "issuesInclExtended"#,
  # "committer"#,
  # "omc",
  # "otc",
  # "former_gt_all",
  # "former_gt_timed"
)

COMPUTE_GT_SET = c(
  "CoreClassification"#,
  # "LOC",
  # "CC",
  # "CC_LOC",
  # "Union",
  # "Intersect",
  # "Other_GT"
)

get_available_gts <- function(){
  available_gts = c(
                  #  "all_data",
                    "issues",
                    "issuesInclExtended"#,
                  #  "committer",
                  #  "omc",
                  #  "otc",
                  #  "former_gt_all",
                  #  "former_gt_timed"
                   )
  return(available_gts)
}

review_committer <- function() {

  main_table <- list()
  main_table["committer"] = list(unique(c(
    # Add committers' names
  )))

  return(main_table)
}

filter_issues <- function(project.data) {
  project.data$set.issues(filter(project.data$get.issues(),
                                 author.name != "dependabotbot"
                                 & author.name != "buildkitebot"
                                 & author.name != "github-pagesbot"
                                 & author.name != "googlebot"
                                 & author.name != "google-clabot"
                                 & author.name != "google-data-collectionbot"
                                 & author.name != "lgtm-combot"
                                 & author.name != "travis-cibot"
                                 & author.name != "copybara-servicebot"
                                 & author.name != "GitHub"
                                 ))
  return(project.data)
}
