## Copyright 2020 Nils Alznauer <s9nialzn@stud.uni-saarland.de>
## Copyright 2021-2022 Thomas Bock <bockthom@cs.uni-saarland.de>
## All Rights Reserved.

GROUND_TRUTHS = c(
  # "all_data",
  "issues",
  "issuesInclExtended",
  "committer"#,
  # "omc",
  # "otc",
  # "former_gt_all",
  # "former_gt_timed"
)

COMPUTE_GT_SET = c(
  "CoreClassification",
  # "LOC",
  # "CC",
  # "CC_LOC",
  # "Union",
  # "Intersect",
  "Other_GT"
)

get_available_gts <- function(){
  available_gts = c(
                  #  "all_data",
                    "issues",
                    "issuesInclExtended",
                    "committer"#,
                  #  "omc",
                  #  "otc",
                  #  "former_gt_all",
                  #  "former_gt_timed"
                   )
  return(available_gts)
}

review_committer <- function() {

  main_table <- list()
  main_table["committer"] = list(unique(c(
    # Source: https://github.com/kubernetes/kubernetes/blob/a1908ecc211c4396335aad2ab6df2d09282a690e/OWNERS (2020-12-06)
    # approvers & reviewers:
    "Brendan Burns", # brendandburns
    "Dawn Chen", # dchen1107
    "Daniel Smith", # lavalamp
    "Clayton Coleman", # smarterclayton
    "Tim Hockin", # thockin
    "Jordan Liggitt", # liggitt
    "Wojciech Tyczynski", # wojtek-t
    # emeritus approvers:
    # "Joe Beda", # jbeda
    # "bgrant0607"

    # additional:
    # sig-architecture:
    "derekwaynecarr",
    "Davanum Srinivas", # dims
    "John Belamaric", # johnbelamaric
    "Zhonghu Xu", # hzxuzhonghu, only reviewer
    # sig-auth:
    "Dr. Stefan Schimanski", # sttts
    "Tim Allclair", # tallclair
    "David Eads", # deads2k
    "Mike Danese", # mikedanese
    "Monis Khan", # enj, only reviewer
    "erictune",
    "Jianhui Z", # jianhuiz, only reviewer
    "Matt Liggett", # mml
    "Andy Goldstein", # ncdc, only reviewer
    "nikhiljindal",
    "Andrew Lytvynov", # awly, only reviewer
    "Chao Xu", # caesarxuchao
    "Ilya Dmitrichenko", # errordeveloper, only reviewer
    "Timothy St. Clair", # timothysc
    "Alexandr Tcherniakhovski", # immutableT
    "Mehdy Bohlool", # mbohlool, only reviewer
    "Mayank Kumar", # krmayankk, only reviewer
    "WanLinghao", # only reviewer
    # sig-release:
    "alejandrox1",
    "Stephen Augustus", # justaugustus
    "Sascha Grunert", # saschagruntert
    "Tim Pepper", # tpepper
    "cpanato", # only reviewer
    "Pengfei Ni", # feisky, feiskyer
    "hasheddan", # only reviewer
    "Hannes Hoerl", # hoegaarden, only reviewer
    "Benjamin Elder", # BenTheElder
    "Christoph Blecker", # cblecker
    "Linus Arver", # listx
    # sig-storage:
    "saad-ali",
    "Jan Safranek", # jsafrane
    "Hemant Kumar", # gnufied
    "Michelle Au", # msau42
    "Jing Xu", # jungxu97, only reviewer
    "Cheng Xing", # verult, only reviewer
    "Humble Devassy Chirammal", # humblec
    # sig-scheduling (NO reviewer or approver):
    "Aldo Culquicondor", # alculquicondor
    "Da K. Ma", # k82cn
    "ravisantoshgudimetla",
    "Wei Huang", # Huang-Wei,
    "Abdullah Gharaibeh", # ahg-g
    "Lei Zhang", #Lei Zhang (Harry) resouer
    "Leon Wang", # wgliang
    "draveness",
    "Jun Gong", # hex108
    "Cong Liu", # liu-cong
    "Mike Dame", # damemi
    # sig-cli (NO reviewer or approver):
    "JanetKuo", # janetkou
    "Sean Sullivan", # seans3
    "Jeff Regan", # monopole
    "Sunil Arora", # droot
    "Antoine Pelisse", # apelisse
    "ymqytw", # mengqiy
    "Maciej Szulik", # soltysh
    "Phillip Wittrock", # pwittrock
    "brianpursley",
    "Di Xu", #dixudx
    "rootfs",
    "Shiyang Wang", # shiywang
    "zhouya0",
    # sig-testing:
    "Erick Fejta", # fejta
    "Aaron Crickenberger", # spiffxp
    # sig-node:
    "Lantao Liu", # Random-Liu
    "David Ashpole", # dashpole
    "Vishnu Kannan", # vishh
    "Yu-Ju Hong", # yujuhong
    "Michael Taufen", # mtaufen
    "bindata-mockuser", # pmorie
    "Seth Jennings", # sjenning
    "Yifan Gu", # yifan-gu
    "Matt McNaughton", # mattjmcnaughton, only reviewer
    "Matthias Bertschy", # matthyx, only reviewer
    "Odin Ugedal", # odinuge, only reviewer
    "Dan Williams", # dcbw
    "Minhan Xia", # freehan
    # sig-network:
    "Andrew Sy Kim", # andrewsykim
    "Bowei Du", # bowei
    "Antonio Ojea", # aojea, only reviewer
    "Casey Davenport", # caseydavenport
    "Dan Winship", # danwinship
    "MrHohn",
    "d00369826", # m1093782566, only reviewer
    "Christopher M. Luciano", # cmluciano, only reviewer
    "Rohit Ramkumar", # rramkumar1, only reviewer
    "Kenneth Owens", # kow3ns
    "Tomas Nozicka", # tnozicka
    "Anthony Yeh", # enisoc
    "Anirudh", # foxish
    "Morten Torkildsen", # mortent, only reviewer
    "Aleksandra Malinowska",
    "Beata Skiba", # bskiba
    "Maciej Pytel",
    "Marcin Wielgus", # mwielgus
    "Frederic Branczyk", # brancz
    "Han Kang", # logicalhan
    "Elana Hashman", # ehashman
    "Hongcai Ren", # RainbowMango
    "Marek Siarkowicz", # serathius
    "Karol Wychowaniec", # kawych, only reviewer
    "Sergiusz Urbaniak", # s-urbaniak, only reviewer
    "Solly Ross", # DirectXMan12, only reviewer
    "Daniel Kłobuszewski", # x13n, only reviewer
    "Marian Lobur", # loburm, only reviewer
    "frank-huangyuqi", # huangyuqi, only reviewer
    "andyxning", # only reviewer
    "Pat Christopher", # coffeepac, only reviewer
    "André Bauer", # monotek, only reviewer
    # api-reviewers:
    "Marek Grabowski", # gmarek
    "David Oppenheimer", # davidopp, only reviewer
    "Lucas Käldström", # luxas
    "Justin Santa Barbara", # justinsb
    "Piotr Szczesniak", # piosz
    "Joe Betz", # jpbetz
    "wfender", # cheftako
    "Jorge O. Castro", # castrojo
    "Bob Killen", # mrbobbytables
    # sig-docs:
    "Jim Angel", # jimangel
    "Kaitlyn Barnard", # kbarnard10
    "zacharysarah",
    "Karen Bradshaw", # kbhawkey
    "Taylor Dolezal", # onlydole
    "Tim Bannister", # sftim
    "Mateusz Matejczyk", # mm4tt
    "Patrick Lang", #PatrickLang, only reviewer
    "Deep Debroy", # ddebroy, only reviewer
    "Ben Moss", # benmoss
    # feature-approvers:
    "caleb miles", # calebmiles
    "Bob Wise", # countspongebob
    "Christian Bell", # csbell
    "Jason Singer DuMars", # jdumars
    "Matt Farina", # mattfarina
    "Michael Michael", # michmike
    "Adnan Abdulhussein", # prydonius
    "Quinton Hoole", # quinton-hoole

    # owners files of sub(sub*)directories:
    "CJ Cullen", # cjcullen
    "Haowei Cai", # roycaihw
    "Karan Goel", # karan, only reviewer
    "Yang Guo", # yguo0905
    "Peter Hornyack", # pjh
    "Yu Liao", # yliaog
    "Shyam Jeedigunta", # shyamjvs
    "Wenjia Zhang", # wenjiaswe, only reviewer
    "Lubomir I. Ivanov", # neolit123
    "John Schnake", # johnSchnake, only reviewer
    "Steve Sloka", # stevesloka, only reviewer
    "Srini Brahmaroutu", # brahmaroutu, only reviewer
    "stewart-yu", # stewart-yu
    "Steve Kuznetsov", # stevekuznetsov
    "Min Kim", # yue9944882, only reviewer
    "Alex Robinson", # a-robinson, only reviewer
    "Jan Chaloupka", # ingvagabund, only reviewer
    "Jay V", # jayunit100, only reviewer
    "Jason Lowdermilk", # jlowdermilk, only reviewer
    "Johannes M. Scheuermann", # johscheuer, only reviewer
    "Madhusudan.C.S", # madhusudancs, only reviewer
    "Liang Mingqiang", # mqliang, only reviewer
    "ping035627", # ping035627, only reviewer
    "Rob Rati", # rrati, only reviewer
    "Scott Creeley", # screeley44, only reviewer
    "fabriziopandini",
    "Rostislav M. Georgiev", # rosti
    "Rafael Fernández López", # ereslibre
    "Alexander Kanevskiy", # kad, only reviewer
    "Jason DeTiberus", # detiber, only reviewer
    "Yago Nobre", # yagonobre, only reviewer
    "SataQiu", # SataQiu
    "Yassine TIJANI", # yastij
    # "xiangpengzhao", # (possible future reviewer)
    # "leigh capili", # stealthybox (possible future reviewer)
    # "liz", # liztio (possible future reviewer)
    # "Chuck Ha", # chuckha (possible future reviewer)
    "juanvallejo", # only reviewer
    "li mengyang", # hwdef, only reviewer
    "aaa", #"lIuDuI", # xichengliudui, only reviewer
    "pweil-", # only reviewer
    "Rodrigo Campos", # rata, only reviewer
    "Dario Minonne", # sdminonne, only reviewer
    "krousey",
    "Rudi C", # therc, only reviewer
    "Łukasz Oleś", # lukaszo, only reviewer
    "Kevin Wang", # kevin-wangzefeng, only reviewer
    "Sidhartha Mani", # wlan0
    "Jing Xu", # jingxu97
    "Mike Crute", # mcrute, only reviewer
    "Yecheng Fu", # cofyc
    "lichuqiang", # only reviewer
    "Patrick Ohly", # pohly
    "Rob Scott", # robscott
    "Joseph Burnett", # josephburnett
    "Avesh Agarwal", # aveshagarwal, only reviewer
    "chrislovecnm", # only reviewer
    "andyzhangx",
    "Khaled Henidak (Kal)", # khenidak
    "Dong Liu", # karataliu
    "Connor Doyle", # ConnorDoyle
    "Kevin Klues", # klueska
    "Louise Daly", # lmdaly
    "nolancon", # only reviewer
    "Jiaying Zhang", # jiayingz
    "Rohit Agarwal", # mindprince, only reviewer
    "Renaud Gaubert", # RenaudWasTaken, only reviewer
    "Vikas Choudhary", # vikaschoudhary16, only reviewer
    "Balaji Subramaniam", # balajismaniam
    "Tara Gu", # taragu
    "David Zhu", # davidz627
    "Hongchao Deng", # hongchaodeng, only reviewer
    "Ivan Shvedunov", # ivan4th, only reviewer
    "Luis Pabón", # lpabon, only reviewer
    "Mitsuhiro Tanino", # mtanino, only reviewer
    "Chakri Nelluri", # chakri-nelluri
    "Angus Lees", # anguslees
    "FengyunPan2",
    "Rita Zhang", # ritazh, only reviewer
    "Jeff Vance", # jeffvance, only reviewer
    "SandeepPissay",
    "Balu Dontu", # BaluDontu
    "Divyen Patel", # divyenpatel
    "Eric Ernst", # egernst, only reviewer
    "James Munnelly", # munnerz
    "Nikhita Raghunath", # nikhita
    "liangwei", # Lion-Wei, only reviewer
    "Cheng Pan", # leakingtapan, only reviewer
    "jennybuckley", # only reviewer
    "tanjunchen", # only reviewer
    "Manjunath A Kumatagi", # mkumatag
    "Yongkun Anfernee Gui", # anfernee
    "bprashanth",
    "Claudiu Belu", # claudiubelu
    "vpickard", # only reviewer
    "Ed Bartosh", # bart0sh, only reviewer
    "Roy Yang", # bsdnet, only reviewer
    "Morgan Bauer" # MHBauer, only reviewer

  )))

  return(main_table)
}

filter_issues <- function(project.data) {
  project.data$set.issues(filter(project.data$get.issues(),
                                 author.name != "GitHub"
                                 ))
  return(project.data)
}
