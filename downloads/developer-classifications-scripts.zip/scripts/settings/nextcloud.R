## Copyright 2020 Nils Alznauer <s9nialzn@stud.uni-saarland.de>
## Copyright 2021-2022 Thomas Bock <bockthom@cs.uni-saarland.de>
## All Rights Reserved.

GROUND_TRUTHS = c(
  # "all_data",
  "issues",
  "issuesInclExtended"#,
  # "committer"#,
  # "omc",
  # "otc",
  # "former_gt_all",
  # "former_gt_timed"
)

COMPUTE_GT_SET = c(
  "CoreClassification"#,
  # "LOC",
  # "CC",
  # "CC_LOC",
  # "Union",
  # "Intersect",
  # "Other_GT"
)

get_available_gts <- function(){
  available_gts = c(
                  #  "all_data",
                    "issues",
                    "issuesInclExtended"#,
                  #  "committer",
                  #  "omc",
                  #  "otc",
                  #  "former_gt_all",
                  #  "former_gt_timed"
                   )
  return(available_gts)
}

review_committer <- function() {

  main_table <- list()
  main_table["committer"] = list(unique(c(

    )))

  return(main_table)
}

filter_issues <- function(project.data) {
  project.data$set.issues(filter(project.data$get.issues(),
                                 author.name != "backportbot-nextcloudbot"
                                 & author.name != "cypressbot"
                                 & author.name != "dcobot"
                                 & author.name != "delete-merged-branchbot"
                                 & author.name != "dependabot-previewbot"
                                 & author.name != "dependabotbot"
                                 & author.name != "docker-library-bot"
                                 & author.name != "faily-bot-testbot"
                                 & author.name != "faily-botbot"
                                 & author.name != "fixupbotbot"
                                 & author.name != "github-actionsbot"
                                 & author.name != "invite-contributorsbot"
                                 & author.name != "netlifybot"
                                 & author.name != "nextcloud-android-bot"
                                 & author.name != "nextcloud-bot"
                                 & author.name != "nextcloud-desktop-bot"
                                 & author.name != "nextcloud-pr-bot"
                                 & author.name != "nextcloud-stalebot"
                                 & author.name != "npmbuildbotbot"
                                 & author.name != "travis-cibot"
                                 & author.name != "welcomebot"
                                 ))
  return(project.data)
}
