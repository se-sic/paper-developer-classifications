## Copyright 2020 Nils Alznauer <s9nialzn@stud.uni-saarland.de>
## Copyright 2021-2022 Thomas Bock <bockthom@cs.uni-saarland.de>
## All Rights Reserved.

GROUND_TRUTHS = c(
  # "all_data",
  "issues",
  "issuesInclExtended",
  "committer"#,
  # "omc",
  # "otc",
  # "former_gt_all",
  # "former_gt_timed"
)

COMPUTE_GT_SET = c(
  "CoreClassification",
  # "LOC",
  # "CC",
  # "CC_LOC",
  # "Union",
  # "Intersect",
  "Other_GT"
)

get_available_gts <- function(){
  available_gts = c(
                  #  "all_data",
                    "issues",
                    "issuesInclExtended",
                    "committer"#,
                  #  "omc",
                  #  "otc",
                  #  "former_gt_all",
                  #  "former_gt_timed"
                   )
  return(available_gts)
}

review_committer <- function() {

  main_table <- list()
  main_table["committer"] = list(unique(c(
    # Source: https://angular.io/about?group=Angular (2020-10-10)
    "alan-agius4", # Alan Agius
    "Alex Rickabaugh",
    "Andrew Kushnir",
    "Andrew Scott",
    "Andrew Seguin",
    "Annie Wang",
    "Charles Lyding",
    "cindygk", # Cindy Greene-Kaplan
    "Dave Shevitz",
    "Doug Parker",
    "Emma Twersky",
    "Filipe Silva",
    "Georgios Kalpakas",
    "Greg Magolan",
    "Igor Minar",
    "Jeremy Elbourn",
    "Joey Perrott",
    "Jules Kremer",
    "Kapunahele Wong",
    "Keen", # Keen Yee Liau
    "Kristiyan Kostadinov",
    "Manu Murthy",
    "Michael Prentice",
    "mmalerba",
    "Minko Gechev",
    "Miško Hevery", # Misko Hevery"
    "Paul Gschwendtner",
    "pkozlowski-opensource",
    "Peter Bacon Darwin",
    "Stephen Fluin"
  )))

  return(main_table)
}

filter_issues <- function(project.data) {
  project.data$set.issues(filter(project.data$get.issues(),
                                 author.name != "angular-automatic-lock-botbot"
                                 & author.name != "anuglar-jira-bot"
                                 & author.name != "angular-pullapporve-bot"
                                 & author.name != "angular-robotbot"
                                 & author.name != "angularhqbot"
                                 & author.name != "copybara-servicebot"
                                 & author.name != "dependabotbot"
                                 & author.name != "github-actionsbot"
                                 & author.name != "google-clabot"
                                 & author.name != "google-data-collectionbot"
                                 & author.name != "googlebot"
                                 & author.name != "in-solidaritybot"
                                 & author.name != "jirabot"
                                 & author.name != "ngbotbot"
                                 & author.name != "pullapprovebot"
                                 & author.name != "slackbot"
                                 ))
  return(project.data)
}
