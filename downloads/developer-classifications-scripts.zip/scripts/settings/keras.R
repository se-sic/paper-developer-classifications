## Copyright 2020 Nils Alznauer <s9nialzn@stud.uni-saarland.de>
## Copyright 2021-2022 Thomas Bock <bockthom@cs.uni-saarland.de>
## All Rights Reserved.

GROUND_TRUTHS = c(
  # "all_data",
  "issues",
  "issuesInclExtended",
  "committer"#,
  # "omc",
  # "otc",
  # "former_gt_all",
  # "former_gt_timed"
)

COMPUTE_GT_SET = c(
  "CoreClassification",
  # "LOC",
  # "CC",
  # "CC_LOC",
  # "Union",
  # "Intersect",
  "Other_GT"
)

get_available_gts <- function(){
  available_gts = c(
                  #  "all_data",
                    "issues",
                    "issuesInclExtended",
                    "committer"#,
                  #  "omc",
                  #  "otc",
                  #  "former_gt_all",
                  #  "former_gt_timed"
                   )
  return(available_gts)
}

review_committer <- function() {

  # create the list that will be returned
  main_table <- list()

  # add all people that are confirmed to be core developer / committer by the organization itself
  main_table["committer"] = list(unique(c(
    # Source: https://github.com/keras-team/governance/tree/766f5e72e235fee81e687a21a2f8c7b9a7b8d6ed (2019-09-26)
    "François Chollet", # Francois Chollet
    "farizrahman4u", # Fariz Rahman
    "Frédéric Branchaud-Charron",
    "Taehoon Lee",
    "Gabriel de Marmiesse" # not yet part at snapshot 2019-09-26
  )))

  return(main_table)
}

filter_issues <- function(project.data) {
  project.data$set.issues(filter(project.data$get.issues(),
                                 author.name != "dependabotbot"
                                 & author.name != "copybara-servicebot"
                                 & author.name != "tensorflow-butlerbot"))
  return(project.data)
}
