## Copyright 2022 Thomas Bock <bockthom@cs.uni-saarland.de>
## All Rights Reserved.

# Define devices
devices = c("pdf", "png", "tikz")
#devices = c("pdf")
# Define projects
casestudies = c(
    "angular",
    "atom",
    "bootstrap",
    "deno",
    "electron",
    "flutter",
    "google-data-transfer-project",
    "jquery",
    "keras",
    "kubernetes",
    "moby",
    "nextcloud",
    "nextjs",
    "nodejs",
    "openssl-github",
    "owncloud-github",
    "react",
    "redux",
    "revealjs",
    "tensorflow",
    "threejs",
    "typescript",
    "vue",
    "vscode",
    "webpack"
)

for (case in SIMPLIFY.DIRECTED) {

    combine.classification.results(list.of.casestudies = casestudies, sd = case)

    # Create overall plots
    plot.all(devices = devices, list.of.casestudies = casestudies, sd = case)

    plot.all.gt.devs.not.part.of.classification(devices = devices, list.of.casestudies = casestudies, relative = FALSE, sd = case)
    plot.all.gt.devs.not.part.of.classification(devices = devices, list.of.casestudies = casestudies, relative = TRUE, sd = case)
}

plot.times.between.write.permission.events(devices = devices, list.of.casestudies = casestudies, include.extended.events = FALSE)
plot.times.between.write.permission.events(devices = devices, list.of.casestudies = casestudies, include.extended.events = TRUE)

# Define devices
time.ranges = c("3months", "6months", "9months", "12months")
plot.covered.permission.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                       time.ranges = time.ranges, developer.based = "no", include.extended.events = FALSE)
plot.covered.permission.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                       time.ranges = time.ranges, developer.based = "no", include.extended.events = TRUE)
plot.covered.permission.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                       time.ranges = time.ranges, developer.based = "max", include.extended.events = FALSE)
plot.covered.permission.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                       time.ranges = time.ranges, developer.based = "max", include.extended.events = TRUE)
plot.covered.permission.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                       time.ranges = time.ranges, developer.based = "median", include.extended.events = FALSE)
plot.covered.permission.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                       time.ranges = time.ranges, developer.based = "median", include.extended.events = TRUE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "no", include.extended.events = FALSE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "no", include.extended.events = TRUE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "max", include.extended.events = FALSE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "max", include.extended.events = TRUE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "median", include.extended.events = FALSE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "median", include.extended.events = TRUE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "avg", include.extended.events = FALSE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "avg", include.extended.events = TRUE)

for (case in SIMPLIFY.DIRECTED) {
    plot.sizes.of.gt.and.classified.classes(devices = devices, list.of.casestudies = casestudies, sd = case)
}
