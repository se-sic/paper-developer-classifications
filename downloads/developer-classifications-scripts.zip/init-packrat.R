## Copyright 2017 Thomas Bock <bockthom@fim.uni-passau.de>
## All Rights Reserved.

## bootstrap packrat
cat("Bootstrapping packrat", "\n")
packrat::restore(prompt = FALSE)

