## Copyright 2016-2019 Thomas Bock <bockthom@fim.uni-passau.de>
## Copyright 2019-2021 Thomas Bock <bockthom@cs.uni-saarland.de>
## All Rights Reserved.

## LOAD NEEDED LIBRARIES

suppressPackageStartupMessages(library(argparse)) # for ArgumentParser

## COMMAND LINE PARSER

create.cli.parser = function() {

  ## create parser object
  parser = ArgumentParser()

  ## casestudy
  parser$add_argument(
    "-c", "--casestudy",
    type = "character",
    # nargs = 1,
    help = "Casestudy name as in Codeface-data folder name"
  )

  ## analysis (one of file, function, feature, mail)
  parser$add_argument(
    "-a", "--analysis",
    type = "character",
    # nargs = 1,
    help = "Artifact type to use in the analysis (one of file, function, feature, mail)"
  )

  ## time period
  parser$add_argument(
    "-t", "--time-period",
    type = "character",
    # nargs = 1,
    default = "6months",
    help = "Time period of ranges for splitting functionality (omit spaces in character string!) [default \"%(default)s\"]"
  )

   ## sliding window
  parser$add_argument(
    "-s", "--sliding-window",
    action = "store_true",
    # nargs = 0,
    default = FALSE,
    help = "Use sliding windows for time-based splitting [default \"%(default)s\"]"
  )

  ## networks authors
  parser$add_argument(
    "--networks_authors",
    type = "character",
    # nargs = 1,
    default = "all",
    help = "Whether to restrict authors in networks (one of all, onlyCurrentContributors, onlyPreviousContributors) [default \"%(default)s\"]"
  )

  ## artifact relation
  parser$add_argument(
    "--artifact_relation",
    type = "character",
    # nargs = 1,
    default = "cochange",
    help = "Artifact-relation type to use in the analysis [default \"%(default)s\"]"
  )

  ## author relation
  parser$add_argument(
    "--author_relation",
    type = "character",
    # nargs = 1,
    default = "cochange",
    help = "Author-relation type to use in the analysis (ignored for mail analysis) [default \"%(default)s\"]"
  )


  ## analysis range type
  parser$add_argument(
    "--analysis_range_type",
    type = "character",
    default = "threemonth",
    help = "The selection process for revision windows [default \"%(default)s\"]"
  )

  ## codeface data
  parser$add_argument(
    "-d", "--codeface-data",
    type = "character",
    help = "Path to Codeface data"
  )

  ## output
  parser$add_argument(
    "-o", "--output",
    type = "character",
    help = "Path to store output data"
  )

  return(parser)
}
