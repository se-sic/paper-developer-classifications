#!/bin/bash

## Copyright 2016-2019 Thomas Bock <bockthom@fim.uni-passau.de>
## Copyright 2019-2022 Thomas Bock <bockthom@cs.uni-saarland.de>
## All Rights Reserved.

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

pushd ${DIR} > /dev/null

    # logging
    echo =================================================================
    echo "Calling dev-network-growth with following arguments:"
    echo "$@"
    echo =================================================================
    echo

    Rscript "init-packrat.R" --bootstrap-packrat

    # get parameters from command line
    TMPDIR=$1 # currently ignored

    set -- "${@:2:($#-1)}"

    echo "==============================================================================="
    echo "Calling dev-network-growth with following arguments:"
    echo $@
    echo "==============================================================================="


    SLIDING_WINDOW=""

    if [ "${6}" == "sliding-window" ]
    then
        SLIDING_WINDOW="-s"
    fi

    ARGUMENTS="-c ${3} -o ${1: : -1} -d ${2: : -1} -a ${4} -t ${5} ${SLIDING_WINDOW} --networks_authors ${7} --analysis_range_type ${8} --artifact_relation ${9} --author_relation ${10}"

    ## The R output is logged to an individual logfile for each R script,
    ## as well as to the console.
    R_LOGPATH="${11}/R/${3}_${4}_${5}_${6}_${7}_${8}_${9}_${10}"
    mkdir -p ${11}/R

    getRLogFile() {
        LOGDATE="$(date '+%Y-%m-%d_%H-%M-%S')"
        echo "${R_LOGPATH}_${1}_${LOGDATE}.log"
    }

    Rscript "scripts/run_all.R" ${ARGUMENTS} > >( tee -a $(getRLogFile "classifications") ) 2>&1

popd > /dev/null
