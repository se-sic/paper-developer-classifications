### This is the replication package of the article "Automatic Developer-Role Classification on GitHub: A Validation Study"

In order to run our R scripts, you need to clone coronet (we have tested our scripts with version 4.0 of coronet, https://github.com/se-sic/coronet/archive/v4.0.zip) into a directory named `coronet`  within this directory.
Based on the data format which coronet uses, our scripts are able to read and process the data (using coronet).

Beside the third-party library coronet, our scripts use several other external packages. In the packrat directory, you can find a snapshot file containing all the packages together with their version number that we have used. (However, keep in mind that the snapshot file contains also packages which we did not use in our analysis.)

For our study, we used R version 4.1.1., but also other R versions should work.

---

`run.sh` is our starting script, which takes a lot of different parameters (described either in `configuration-cli.R` or `configuration.R`).
The actual analysis starts in `scripts/run_all.R`.

Disclaimer: In the provided data, we pseudonymized names and e-mail addresses of developers. Therefore, the ground-truth validation cannot performed with this data and the scripts. However, the analysis of the time differenes between events and the assessment of classification methods can be run with the provided pseudonymized data.

Disclaimer: The data are quite huge for some of the subject projects. That is, machines with a high RAM (> 250 MB is recommended) and also many cores are needed.

---

In case of questions, contact Thomas Bock <bockthom@cs.uni-saarland.de>.
