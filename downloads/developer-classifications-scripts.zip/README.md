### This is the replication package of the article "Automatic Developer-Role Classification on GitHub: A Validation Study"

For our study, we used R version 4.1.1., but also other R versions should work.

In order to run our R scripts, you need to clone coronet (we have tested our scripts with version 4.0 of coronet, https://github.com/se-sic/coronet/archive/v4.0.zip) into a directory named `coronet`  within this directory.
Based on the data format which coronet uses, our scripts are able to read and process the data (using coronet).

Beside the third-party library coronet, our scripts use several other external packages. In the packrat directory, you can find a snapshot file containing all the packages together with their version number that we have used. (However, keep in mind that the snapshot file contains also packages which we did not use in our analysis.). To install all the packages via packrat, run `install.packages("packrat")` in your R console and run `packrat::restore()`. Then all the packages of our snapshot should be automatically installed in the required versions. If the packages are not installed automatically, then simply run the script "init-packrat.R" via `Rscript init-packrat.R`.

---

After all the installations are finished, you can start our analysis scripts.
Our main script is `scripts/run_all.R`, which runs all the analysis, but takes lots of different configuration parameters (which are also explained in `configuration-cli.R`):

`-c` [name of the project, see also below]

`-o` [path to the output directory, where all the resulting data and plots should be stored]

`-d` [path to the input directory, that is, the codeface-data directory that contains all the input data of all the projects]

`-t` [<time window length, e.g. "6 months"]

`--networks_authors` [which network vertices to consider: either "all" or "onlyPreviousContributors"]

All the above parameters are mandatory. In addition, there are also non-mandatory parameters, for instance:

`--sliding-window` (use this parameter only when you want to use sliding windows; otherwise, subsequent windows are used)

Additional stuff could be configured in `configuration.R`, but this is usually not necessary. For example, you can configure the number of cores to be used in parallel in line 20 of `configuration.R`.

For the project names (used with parameter `-c`), please use one of the following names:

    "angular",
    "atom",
    "bootstrap",
    "deno",
    "electron",
    "flutter",
    "google-data-transfer-project" (i.e., project DTP), 
    "jquery",
    "keras",
    "kerberos",
    "moby",
    "nextcloud",
    "nextjs",
    "nodejs",
    "openssl-github" (i.e., project openssl),
    "owncloud-github" (i.e., project owncloud),
    "react",
    "redux",
    "revealjs",
    "tensorflow",
    "threejs",
    "typescript",
    "vscode",
    "vue",
    "webpack"

For the input data (see parameter `-d`), there has to be a `codeface-data` directory that contains all the necessary input data that we have extracted from GitHub beforehand. You can download this data (in a pseudonymized version, for data privacy reasons) from our [supplementary website](https://se-sic.github.io/paper-developer-classifications/#downloads) (see the bullet point "Pseudonymized input data" in the Downloads section).

If you run our main script `scripts/run_all.R`, then all the analyses are performed for the given project. In addition, overview plots are generated using data from all projects that have already been analyzed. Here is an exmeplary call to execute our main script:

```
Rscript scripts/run_all.R -c "google-data-transfer-project" -o "/path-to-the-directory-for-the-results/" -d "/path-to-the-input-data/codeface-data" -t "3 months" --sliding-window --networks_authors "onlyPreviousContributors"
```


If you want to generate these overview plots separately, just comment out line 299 in  `scripts/run_all.R` (i.e., `run()`). Also, if you just want to run the analysis without generating the overview plots, then comment out line 301 `scripts/run_all.R` (i.e., `source("scripts/overall-plotting.R")`).

---

**Disclaimer 1:** In the provided data, we pseudonymized names and e-mail addresses of developers. Therefore, the validation of the set of privileged developers (see RQ2) cannot be performed with these data (that is, it will produce wrong results as the names of the developers that appear in the project-reported lists do not appear in pseudonymized data at all). However, the analysis of the time differenes between events (see RQ1) and the assessment of classification methods (see RQ3) can be run with the provided pseudonymized data.

**Disclaimer 2:** The data are quite huge for some of the subject projects. That is, machines with a high RAM (> 250 MB is recommended) and also many cores are needed. If you want to try out the analysis scripts, we recommend to start with one of the smaller projects, such as the "google-data-transfer-project" (DTP).

---

In case of questions, contact Thomas Bock <bockthom@cs.uni-saarland.de>.
