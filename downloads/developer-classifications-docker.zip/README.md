### This is the description of the Dockerfile of the replication package of the article "Automatic Developer-Role Classification on GitHub: A Validation Study"

To ease the installation of our analysis scripts, we provide a Dockerfile for setting up a docker container. Please note that the container will use multiple GB of disc storage after the setup is performed.

To apply this file, we rely on docker and refer to the documentation on how to install docker on your Linux operating system.

After docker is installed, make sure that the docker daemon is running. On systemd, you can use `sudo systemctl start docker` to start the daemon, if necessary.

The container is set up by invoking `sudo docker build -t developer classifications .` in the directory where the Dockerfile is located. By invoking this script, all system dependencies are installed, R 4.1.1 is installed, the analysis scripts were cloned, all the necessary R packages are installed, and the provided pseudonymized input data are downloaded. which might take about an hour.

After setting up the docker container, begin an interactive session via the commmand `run -i -t -v ./results/:/workspace/results/ developer-classifications /bin/bash`. This way, the `results` outside of the container directory is used to store the result data, accessible from inside the container via `/workspace/results/`.

If you are in the interactive session of the container, first change to the analysis directory, in which the analysis scripts are stored inside the container: `cd analysis`

Next, you can start our analysis script. For example, you can use the following call to analyze project DTP:

Rscript scripts/run_all.R -c "google-data-transfer-project" -o "/workspace/results/" -d "/workspace/codeface-data" -t "6 months" --sliding-window --networks_authors "onlyPreviousContributors"

For more details on our analysis scripts, see the following information:

Our main script is `scripts/run_all.R`, which runs all the analysis, but takes lots of different configuration parameters (which are also explained in `configuration-cli.R`):

`-c` [name of the project, see also below]

`-o` [path to the output directory, where all the resulting data and plots should be stored]

`-d` [path to the input directory, that is, the codeface-data directory that contains all the input data of all the projects]

`-t` [<time window length, e.g. "6 months"]

`--networks_authors` [which network vertices to consider: either "all" or "onlyPreviousContributors"]

All the above parameters are mandatory. In addition, there are also non-mandatory parameters, for instance:

`--sliding-window` (use this parameter only when you want to use sliding windows; otherwise, subsequent windows are used)

Additional stuff could be configured in `configuration.R`, but this is usually not necessary. For example, you can configure the number of cores to be used in parallel in line 20 of `configuration.R`.

For the project names (used with parameter `-c`), please use one of the following names:

    "angular",
    "atom",
    "bootstrap",
    "deno",
    "electron",
    "flutter",
    "google-data-transfer-project" (i.e., project DTP),
    "jquery",
    "keras",
    "kerberos",
    "moby",
    "nextcloud",
    "nextjs",
    "nodejs",
    "openssl-github" (i.e., project openssl),
    "owncloud-github" (i.e., project owncloud),
    "react",
    "redux",
    "revealjs",
    "tensorflow",
    "threejs",
    "typescript",
    "vscode",
    "vue",
    "webpack"

For the input data (see parameter `-d`), there has to be a `codeface-data` directory that contains all the necessary input data that we have extracted from GitHub beforehand. These data are already part of the container, stored at `/workspace/codeface-data/`.

If you run our main script `scripts/run_all.R`, then all the analyses are performed for the given project. In addition, overview plots are generated using data from all projects that have already been analyzed.  If you want to generate these overview plots separately, just comment out line 299 in  `scripts/run_all.R` (i.e., `run()`). Also, if you just want to run the analysis without generating the overview plots, then comment out line 301 `scripts/run_all.R` (i.e., `source("scripts/overall-plotting.R")`).

---

**Disclaimer 1:** In the provided data, we pseudonymized names and e-mail addresses of developers. Therefore, the validation of the set of privileged developers (see RQ2) cannot be performed with these data (that is, it will produce wrong results or even fails for some projects, as the names of the developers that appear in the project-reported lists do not appear in pseudonymized data at all; if you would like to skip the failing parts for RQ2, you can comment out line 23 `Other_GT` in `scripts/settings/[project-name].R` for the projects for which we have found project-reported lists to circumvent the pseudonymity problems). However, the analysis of the time differenes between events (see RQ1) and the assessment of classification methods (see RQ3) can be run with the provided pseudonymized data.

**Disclaimer 2:** The data are quite huge for some of the subject projects. That is, machines with a high RAM (> 250 MB is recommended) and also many cores are needed. If you want to try out the analysis scripts, we recommend to start with one of the smaller projects, such as the "google-data-transfer-project" (DTP) or "redux".

---

In case of questions, contact Thomas Bock <bockthom@cs.uni-saarland.de>.
