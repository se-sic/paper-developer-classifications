package wrapper.project.data.gitwrapper;

import java.util.Optional;

@FunctionalInterface
public interface MergeStrategy {

    /**
     * Implements the merge between the {@link Reference References} {@code left} and {@code right}.
     *
     * @param left
     *         the left parent of the merge
     * @param right
     *         the right parent of the merge
     * @return optionally the {@link Status} of the working directory after the merge, if the merge was successful
     */
    Optional<Status> merge(Reference left, Reference right);
}
