package wrapper.project.data.gitwrapper;

import java.nio.file.Path;
import java.util.Collections;
import java.util.List;

/**
 * A merge conflict parsed from the output of 'git blame' by {@link Repository#blameUnmergedFile(Path)} (String)}.
 */
public class MergeConflict {

    /**
     * The lines making up the left side of the conflict. Unmodifiable.
     */
    public final List<BlameLine> left;

    /**
     * The lines making up the right side of the conflict. Unmodifiable.
     */
    public final List<BlameLine> right;

    /**
     * Constructs a new {@link MergeConflict}. The given lists {@code left} and {@code right} will be stored
     * unmodifiable.
     *
     * @param left
     *         the left lines of the conflict
     * @param right
     *         the right lines of the conflict
     */
    MergeConflict(List<BlameLine> left, List<BlameLine> right) {
        this.left = Collections.unmodifiableList(left);
        this.right = Collections.unmodifiableList(right);
    }
}
