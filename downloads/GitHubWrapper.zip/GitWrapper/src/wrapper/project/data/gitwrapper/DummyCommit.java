package wrapper.project.data.gitwrapper;

import java.time.OffsetDateTime;
import java.util.logging.Logger;

/**
 * Represents the dummy commit that is used by git to represent uncommitted changes. Every {@link Repository}
 * constructs its {@link DummyCommit} in its constructor.
 */
final class DummyCommit extends Commit {

    private static final Logger LOG = Logger.getLogger(DummyCommit.class.getCanonicalName());

    /**
     * This commit ID is used for the dummy commit representing uncommitted changes.
     */
    public static final String DUMMY_COMMIT_ID = "0000000000000000000000000000000000000000";

    /**
     * Constructs the dummy {@link Commit} with ID {@value DUMMY_COMMIT_ID} for the given {@link Repository}.
     *
     * @param repo
     *         the {@link Repository} for which this {@link Commit} represents uncommitted changes
     */
    DummyCommit(Repository repo) {
        super(repo, DUMMY_COMMIT_ID);
        super.setAuthor("Not Committed Yet");
        super.setAuthorMail("not.committed.yet");
        super.setAuthorTime(OffsetDateTime.now());
        super.setCommitter("Not Committed Yet");
        super.setCommitterMail("not.committed.yet");
        super.setCommitterTime(OffsetDateTime.now());
    }

    @Override
    void setAuthor(String author) {
        setterWarning();
    }

    @Override
    void setAuthorMail(String authorMail) {
        setterWarning();
    }

    @Override
    void setAuthorTime(OffsetDateTime authorTime) {
        setterWarning();
    }

    @Override
    void setCommitter(String committer) {
        setterWarning();
    }

    @Override
    void setCommitterMail(String committerMail) {
        setterWarning();
    }

    @Override
    void setCommitterTime(OffsetDateTime committerTime) {
        setterWarning();
    }

    private void setterWarning() {
        LOG.finest(() -> "Ignoring a setter call on the DummyCommit for " + repo);
        // TODO gets called often while parsing blame lines
    }
}
