package wrapper.project.data.gitwrapper;

import java.util.Optional;

import wrapper.project.data.processexecutor.ProcessExecutor;

/**
 * A {@link MergeStrategy} representing the default 'git merge' merge implementation.
 */
public class DefaultMergeStrategy implements MergeStrategy {

    private final Repository repo;

    /**
     * The default merge strategy that git uses when no
     * <a href="https://git-scm.com/docs/git-merge#_merge_strategies>git merge</a> strategy is specified.
     *
     * @param repo
     *         the repo the strategy operates on
     */
    public DefaultMergeStrategy(Repository repo) {
        this.repo = repo;
    }

    @Override
    public Optional<Status> merge(Reference left, Reference right) {
        Optional<ProcessExecutor.ExecRes> mergeBase = repo.getGit().exec(repo.getDir(), "merge", "-n", "-q", right.getId());
        return mergeBase.flatMap(res -> repo.getStatus());
    }

    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}
