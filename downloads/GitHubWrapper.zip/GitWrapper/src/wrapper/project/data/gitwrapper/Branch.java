package wrapper.project.data.gitwrapper;

import java.util.Optional;
import java.util.function.Function;
import java.util.logging.Logger;

import wrapper.project.data.processexecutor.ProcessExecutor;

/**
 * A {@link Branch} is a named {@link Reference} to a git branch pointing to a {@link Commit}.
 */
public class Branch extends Reference {

    private static final Logger LOG = Logger.getLogger(Branch.class.getCanonicalName());

    /**
     * Constructs a new {@link Branch} referencing an existing git branch.
     *
     * @param repo
     *         the repo this branch is part of
     * @param name
     *         the branch name
     */
    Branch(Repository repo, String name) {
        super(repo, name);
    }

    /**
     * Checks this branch out, and tries to pull changes on this current branch.
     *
     * @return true if the pull was successful
     */
    public boolean pull() {
        if (!repo.checkout(this)) {
            return false;
        }

        Optional<ProcessExecutor.ExecRes> fetch = git.exec(repo.getDir(), "pull");
        Function<ProcessExecutor.ExecRes, Boolean> toBoolean = res -> {
            boolean failed = git.failed(res);

            if (failed) {
                LOG.warning(() -> String.format("Pull of %s failed.", this));
            }

            return !failed;
        };

        return fetch.map(toBoolean).orElse(false);
    }

    /**
     * Returns the {@link Commit} this {@link Branch} is pointing at or an empty optional if there is an error.
     *
     * @return optionally the tip of this {@link Branch}
     */
    public Optional<Commit> getTip() {
        return repo.toHash(id).map(repo::getCommitUnchecked);
    }

    /**
     * Returns the name of this {@link Branch} e.g. 'master' or 'origin/master'.
     *
     * @return the name of this {@link Branch}
     */
    @Override
    public String getId() {
        return id;
    }
}
