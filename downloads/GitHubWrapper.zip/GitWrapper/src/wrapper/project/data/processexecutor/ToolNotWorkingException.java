package wrapper.project.data.processexecutor;

/**
 * An {@link Exception} indicating that a wrapped tool is not working.
 */
public class ToolNotWorkingException extends Exception {

    private static final long serialVersionUID = 1L;

    public ToolNotWorkingException() {}

    public ToolNotWorkingException(String message) {
        super(message);
    }

    public ToolNotWorkingException(String message, Throwable cause) {
        super(message, cause);
    }

    public ToolNotWorkingException(Throwable cause) {
        super(cause);
    }

    public ToolNotWorkingException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
